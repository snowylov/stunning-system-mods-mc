package com.noobvill.power.client;

import java.util.EnumMap;
import java.util.Map;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class SkinCustomizationScreen extends Screen {
    private final Screen parent;
    private final SkinCustomizationConfig config = NoobvillPowerClientState.config();
    private final Map<Outfit, ButtonWidget> outfitButtons = new EnumMap<>(Outfit.class);
    private ButtonWidget toggleButton;

    public SkinCustomizationScreen(Screen parent) {
        super(Text.translatable("screen.noobvill_power.skin_customization"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        outfitButtons.clear();
        int controlsX = width / 2 + 8;
        int controlsWidth = Math.min(190, width / 2 - 24);
        int buttonWidth = (controlsWidth - 6) / 2;
        int top = Math.max(48, height / 2 - 82);

        toggleButton = addDrawableChild(ButtonWidget.builder(toggleText(), button -> {
            config.toggle();
            refreshLabels();
        }).dimensions(controlsX, top, controlsWidth, 20).build());

        Outfit[] outfits = Outfit.values();
        for (int index = 0; index < outfits.length; index++) {
            Outfit outfit = outfits[index];
            int x = controlsX + (index % 2) * (buttonWidth + 6);
            int y = top + 28 + (index / 2) * 24;
            ButtonWidget button = addDrawableChild(ButtonWidget.builder(outfitText(outfit), pressed -> {
                config.select(outfit);
                refreshLabels();
            }).dimensions(x, y, buttonWidth, 20).build());
            outfitButtons.put(outfit, button);
        }

        addDrawableChild(ButtonWidget.builder(Text.translatable("gui.done"), button -> close())
                .dimensions(controlsX, top + 106, controlsWidth, 20).build());
    }

    private Text toggleText() {
        return Text.translatable(config.enabled()
                ? "screen.noobvill_power.outfits_on"
                : "screen.noobvill_power.outfits_off");
    }

    private Text outfitText(Outfit outfit) {
        if (config.selectedOutfit() == outfit) {
            return Text.literal("▶ ").append(outfit.displayName());
        }
        return outfit.displayName();
    }

    private void refreshLabels() {
        toggleButton.setMessage(toggleText());
        outfitButtons.forEach((outfit, button) -> button.setMessage(outfitText(outfit)));
    }

    @Override
    public void close() {
        if (client != null) {
            client.setScreen(parent);
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
        renderBackground(context, mouseX, mouseY, deltaTicks);
        int previewLeft = Math.max(14, width / 2 - 198);
        int previewRight = width / 2 - 10;
        int previewTop = 38;
        int previewBottom = height - 38;
        context.fill(previewLeft, previewTop, previewRight, previewBottom, 0x88000000);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 14, 0xFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer,
                Text.translatable("screen.noobvill_power.preview_hint"),
                (previewLeft + previewRight) / 2, previewBottom - 14, 0xA0A0A0);
        if (client != null && client.player != null) {
            int size = Math.min(70, Math.max(36, (previewBottom - previewTop - 28) / 2));
            InventoryScreen.drawEntity(context, previewLeft, previewTop + 4, previewRight,
                    previewBottom - 18, size, 0.0625F, mouseX, mouseY, client.player);
        }
        super.render(context, mouseX, mouseY, deltaTicks);
    }
}
