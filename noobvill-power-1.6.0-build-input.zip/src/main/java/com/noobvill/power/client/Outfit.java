package com.noobvill.power.client;

import com.noobvill.power.NoobvillPower;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public enum Outfit {
    LIME("lime_wetsuit"),
    MINT("mint_wetsuit"),
    BLUE("blue_wetsuit"),
    PURPLE("purple_wetsuit"),
    PINK("pink_wetsuit"),
    AQUA("aqua_wetsuit");

    private final String id;
    private final Identifier texture;

    Outfit(String id) {
        this.id = id;
        this.texture = NoobvillPower.id("textures/outfit/" + id + ".png");
    }

    public String id() {
        return id;
    }

    public Identifier texture() {
        return texture;
    }

    public Text displayName() {
        return Text.translatable("outfit.noobvill_power." + id);
    }

    public static Outfit byId(String id) {
        for (Outfit outfit : values()) {
            if (outfit.id.equals(id)) {
                return outfit;
            }
        }
        return LIME;
    }
}
