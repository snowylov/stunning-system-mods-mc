package com.noobvill.power;

import com.noobvill.power.client.WetsuitFeatureRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback;
import net.minecraft.client.render.BlockRenderLayer;
import net.minecraft.client.render.entity.PlayerEntityRenderer;

public final class NoobvillPowerClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        BlockRenderLayerMap.putBlock(ModContent.FORCE_FIELD, BlockRenderLayer.TRANSLUCENT);
        LivingEntityFeatureRendererRegistrationCallback.EVENT.register(
                (entityType, entityRenderer, registrationHelper, context) -> {
                    if (entityRenderer instanceof PlayerEntityRenderer playerRenderer) {
                        registrationHelper.register(new WetsuitFeatureRenderer(playerRenderer));
                    }
                });
    }
}
