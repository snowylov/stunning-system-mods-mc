package com.noobvill.power.client;

import com.noobvill.power.NoobvillPower;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public enum Outfit {
    LIME("lime_wetsuit", false),
    MINT("mint_wetsuit", false),
    BLUE("blue_wetsuit", false),
    PURPLE("purple_wetsuit", false),
    PINK("pink_wetsuit", false),
    AQUA("aqua_wetsuit", false),
    CUSTOM_WETSUIT("custom_wetsuit", true),
    LONG_SOCKS("long_socks", true),
    SWIMSUIT("swimsuit", true),
    SWIMMING_TRUNKS("swimming_trunks", true),
    SHORTS("shorts", true),
    TWO_TONE_SHORTS("two_tone_shorts", true);

    private final String id;
    private final Identifier texture;
    private final boolean colorizable;

    Outfit(String id, boolean colorizable) {
        this.id = id;
        this.texture = NoobvillPower.id("textures/outfit/" + id + ".png");
        this.colorizable = colorizable;
    }

    public String id() {
        return id;
    }

    public Identifier texture() {
        return texture;
    }

    public boolean colorizable() {
        return colorizable;
    }

    public Text displayName() {
        return Text.translatable("outfit.noobvill_power." + id);
    }

    public static Outfit byId(String id) {
        for (Outfit outfit : values()) {
            if (outfit.id.equals(id)) {
                return outfit;
            }
        }
        return LIME;
    }
}
