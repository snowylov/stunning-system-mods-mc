package com.noobvill.power.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;

public final class WetsuitFeatureRenderer
        extends FeatureRenderer<PlayerEntityRenderState, PlayerEntityModel> {
    private final WetsuitModel model = new WetsuitModel();

    public WetsuitFeatureRenderer(FeatureRendererContext<PlayerEntityRenderState, PlayerEntityModel> context) {
        super(context);
    }

    @Override
    public void render(MatrixStack matrices, OrderedRenderCommandQueue queue, int light,
            PlayerEntityRenderState state, float limbAngle, float limbDistance) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || state.id != client.player.getId()) {
            return;
        }
        SkinCustomizationConfig config = NoobvillPowerClientState.config();
        if (!config.enabled()) {
            return;
        }
        model.setAngles(state);
        Outfit outfit = config.selectedOutfit();
        renderModel(model, outfit.texture(), matrices, queue, light, state, config.color(outfit), 0);
    }
}
