package com.noobvill.power.client;

import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

final class RgbSliderWidget extends SliderWidget {
    enum Channel {
        RED("screen.noobvill_power.red"),
        GREEN("screen.noobvill_power.green"),
        BLUE("screen.noobvill_power.blue");

        private final String translationKey;

        Channel(String translationKey) {
            this.translationKey = translationKey;
        }
    }

    private final SkinCustomizationConfig config;
    private final Channel channel;

    RgbSliderWidget(int x, int y, int width, Channel channel, SkinCustomizationConfig config) {
        super(x, y, width, 20, Text.empty(), component(config, channel) / 255.0);
        this.config = config;
        this.channel = channel;
        updateMessage();
    }

    void syncFromConfig() {
        value = component(config, channel) / 255.0;
        updateMessage();
    }

    @Override
    protected void updateMessage() {
        if (channel != null) {
            setMessage(Text.translatable(channel.translationKey, currentValue()));
        }
    }

    @Override
    protected void applyValue() {
        if (config == null || channel == null) {
            return;
        }
        int component = currentValue();
        switch (channel) {
            case RED -> config.setRed(component);
            case GREEN -> config.setGreen(component);
            case BLUE -> config.setBlue(component);
        }
    }

    private int currentValue() {
        return (int) Math.round(value * 255.0);
    }

    private static int component(SkinCustomizationConfig config, Channel channel) {
        return switch (channel) {
            case RED -> config.red();
            case GREEN -> config.green();
            case BLUE -> config.blue();
        };
    }
}
