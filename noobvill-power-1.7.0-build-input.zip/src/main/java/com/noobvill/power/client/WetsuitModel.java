package com.noobvill.power.client;

import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;

public final class WetsuitModel extends BipedEntityModel<PlayerEntityRenderState> {
    private static final Dilation SHELL = new Dilation(0.24F);

    public WetsuitModel() {
        super(createTexturedModelData().createModel());
    }

    private static TexturedModelData createTexturedModelData() {
        ModelData data = new ModelData();
        ModelPartData root = data.getRoot();
        root.addChild("head", ModelPartBuilder.create().uv(0, 0)
                .cuboid(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F, SHELL), ModelTransform.NONE);
        root.addChild("hat", ModelPartBuilder.create(), ModelTransform.NONE);
        root.addChild("body", ModelPartBuilder.create().uv(16, 16)
                .cuboid(-4.0F, 0.0F, -2.0F, 8.0F, 12.0F, 4.0F, SHELL), ModelTransform.NONE);
        root.addChild("right_arm", ModelPartBuilder.create().uv(40, 16)
                .cuboid(-3.0F, -2.0F, -2.0F, 4.0F, 12.0F, 4.0F, SHELL),
                ModelTransform.origin(-5.0F, 2.0F, 0.0F));
        root.addChild("left_arm", ModelPartBuilder.create().uv(40, 16).mirrored()
                .cuboid(-1.0F, -2.0F, -2.0F, 4.0F, 12.0F, 4.0F, SHELL),
                ModelTransform.origin(5.0F, 2.0F, 0.0F));
        root.addChild("right_leg", ModelPartBuilder.create().uv(0, 16)
                .cuboid(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F, SHELL),
                ModelTransform.origin(-1.9F, 12.0F, 0.0F));
        root.addChild("left_leg", ModelPartBuilder.create().uv(0, 16).mirrored()
                .cuboid(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F, SHELL),
                ModelTransform.origin(1.9F, 12.0F, 0.0F));
        return TexturedModelData.of(data, 64, 32);
    }
}
