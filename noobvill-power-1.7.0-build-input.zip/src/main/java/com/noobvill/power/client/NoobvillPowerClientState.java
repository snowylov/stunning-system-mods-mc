package com.noobvill.power.client;

public final class NoobvillPowerClientState {
    private static SkinCustomizationConfig config = SkinCustomizationConfig.load();

    private NoobvillPowerClientState() {
    }

    public static SkinCustomizationConfig config() {
        return config;
    }
}
