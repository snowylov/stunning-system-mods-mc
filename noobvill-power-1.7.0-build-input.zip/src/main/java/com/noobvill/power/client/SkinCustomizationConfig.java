package com.noobvill.power.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.noobvill.power.NoobvillPower;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import net.fabricmc.loader.api.FabricLoader;

public final class SkinCustomizationConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir()
            .resolve("noobvill_power-skin-customization.json");

    private boolean enabled = true;
    private String selectedOutfit = Outfit.LIME.id();
    private Map<String, Integer> outfitColors = new HashMap<>();

    private SkinCustomizationConfig() {
    }

    public static SkinCustomizationConfig load() {
        if (!Files.isRegularFile(PATH)) {
            return new SkinCustomizationConfig();
        }
        try (Reader reader = Files.newBufferedReader(PATH, StandardCharsets.UTF_8)) {
            SkinCustomizationConfig config = GSON.fromJson(reader, SkinCustomizationConfig.class);
            if (config == null) {
                return new SkinCustomizationConfig();
            }
            config.selectedOutfit = Outfit.byId(config.selectedOutfit).id();
            if (config.outfitColors == null) {
                config.outfitColors = new HashMap<>();
            }
            config.outfitColors.replaceAll((id, color) -> color == null ? 0xFFFFFF : color & 0xFFFFFF);
            return config;
        } catch (IOException | RuntimeException exception) {
            NoobvillPower.LOGGER.warn("Could not load skin customization config", exception);
            return new SkinCustomizationConfig();
        }
    }

    public boolean enabled() {
        return enabled;
    }

    public Outfit selectedOutfit() {
        return Outfit.byId(selectedOutfit);
    }

    public int color(Outfit outfit) {
        if (!outfit.colorizable()) {
            return -1;
        }
        return 0xFF000000 | (outfitColors.getOrDefault(outfit.id(), 0xFFFFFF) & 0xFFFFFF);
    }

    public int red() {
        return color(selectedOutfit()) >> 16 & 0xFF;
    }

    public int green() {
        return color(selectedOutfit()) >> 8 & 0xFF;
    }

    public int blue() {
        return color(selectedOutfit()) & 0xFF;
    }

    public void setRed(int red) {
        setColor((clamp(red) << 16) | (green() << 8) | blue());
    }

    public void setGreen(int green) {
        setColor((red() << 16) | (clamp(green) << 8) | blue());
    }

    public void setBlue(int blue) {
        setColor((red() << 16) | (green() << 8) | clamp(blue));
    }

    private void setColor(int color) {
        Outfit outfit = selectedOutfit();
        if (!outfit.colorizable()) {
            return;
        }
        outfitColors.put(outfit.id(), color & 0xFFFFFF);
        save();
    }

    private static int clamp(int value) {
        return Math.max(0, Math.min(255, value));
    }

    public void toggle() {
        enabled = !enabled;
        save();
    }

    public void select(Outfit outfit) {
        selectedOutfit = outfit.id();
        enabled = true;
        save();
    }

    public void save() {
        try {
            Files.createDirectories(PATH.getParent());
            try (Writer writer = Files.newBufferedWriter(PATH, StandardCharsets.UTF_8)) {
                GSON.toJson(this, writer);
            }
        } catch (IOException exception) {
            NoobvillPower.LOGGER.warn("Could not save skin customization config", exception);
        }
    }
}
