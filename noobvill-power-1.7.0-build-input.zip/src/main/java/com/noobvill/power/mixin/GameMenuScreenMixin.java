package com.noobvill.power.mixin;

import com.noobvill.power.client.SkinCustomizationScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameMenuScreen.class)
public abstract class GameMenuScreenMixin extends Screen {
    @Shadow
    private ButtonWidget exitButton;

    protected GameMenuScreenMixin(Text title) {
        super(title);
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void noobvillPower$addSkinCustomizationButton(CallbackInfo ci) {
        if (exitButton == null) {
            return;
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("❄"), button ->
                        MinecraftClient.getInstance().setScreen(
                                new SkinCustomizationScreen((Screen) (Object) this)))
                .tooltip(Tooltip.of(Text.translatable("button.noobvill_power.skin_customization")))
                .dimensions(exitButton.getX() - 24, exitButton.getY(), 20, 20)
                .build());
    }
}
