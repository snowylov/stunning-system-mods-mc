# Noobvill Power & Forcefields

Fabric 1.21.11 mod containing the compressed-coal/industrial-diamond material chain,
power crystals, Redstone Hearts, and a modular force-field projector.

## Skin customization

The pause menu has a square white-snowflake button immediately to the left of **Save and Quit to
Title**. It opens the Skin Customization screen, where the outfit layer can be toggled and one of
six supplied wetsuits or six colorizable outfits can be selected. The new choices are a wetsuit,
long socks, swimsuit, swimming trunks, shorts, and two-tone shorts. Red, green, and blue sliders
appear only while one of these color options is selected. Each colorizable outfit remembers its
own RGB value in the client config. The choice applies to the local player in third person as well
as the live mouse-rotated character preview.

Wetsuits use their original 64x32 texture layout on an inflated 3D model shell. Arms and legs use
the classic armor-style mirrored mapping, and ordinary vanilla armor keeps its normal 3D cuboid
layer outside the wetsuit.

## Hazmat suit

The supplied Hazmat textures are used for four wearable pieces. Every piece has the `hazmat suit`
description and is available in the Redstone creative tab.

- Hazmat Mask: 20% longer underwater breathing and 20% dark vision.
- Hazmat Shirt: 50% poison, wither, and harming immunity.
- Hazmat Pants: 11% movement speed and 50% poison, wither, and harming immunity.
- Rubber Boots: 50% fall-damage reduction.

The shirt and pants stack to complete immunity. These effects are exposed as tracked attributes:
`noobvill_power:fall_damage_reduction`, `noobvill_power:underwater_breathing`,
`noobvill_power:dark_vision`, and `noobvill_power:hazard_immunity`. The four items are also in the
common `#c:hazmat_armor` item tag and have individual common tags.

## Cobblestone Piston

The Cobblestone Piston has normal vanilla piston behavior and uses the supplied stone-and-oak
textures for its base. Its extended arm and head use Minecraft's vanilla piston extension assets.
Craft it with three oak planks across the top, three cobblestone across the middle, and
cobblestone, redstone dust, cobblestone across the bottom.

## Redstone Heart lamps

All five lamps emit light level 7 while unpowered and light level 15 while powered. Their default
mode looks for a Redstone Heart within three blocks. Sneak-right-click a placed lamp to switch it
to ordinary Redstone-signal mode; sneak-right-click it again to switch back. The item tooltips also
explain this control.

- Rose Lamp: eight `#c:ingots/rose_gold` around one Redstone Heart.
- Love Lamp: eight pink wool around one Redstone Heart. While powered, adult animals in a 16x16
  horizontal area enter love mode.
- Moon: eight amethyst shards around one Redstone Heart. On full-moon nights, or while otherwise
  powered, it emits light level 15 and a Redstone signal of 15.
- Healing Lamp: eight glistering melon slices around one Redstone Heart. While powered, it heals
  nearby players, animals, and pets by half a heart each second.
- Sun Lantern: eight gold ingots around one Redstone Heart.

Every lamp has both an individual `c` item/block tag and membership in the aggregate `c:lamps`
item/block tags. The Rose Lamp recipe deliberately uses the common rose-gold ingot tag so it works
with any installed mod that supplies compatible rose gold.

## Projector controls

1. Place a Redstone Heart within three blocks of the projector.
2. Right-click the projector with a cube, sphere, cylinder, or tube module to choose its shape.
3. Right-click with a scale module to increase radius; sneak-right-click to decrease it.
4. Use the X, Y, or Z offset module to move the field on that axis; sneak-right-click reverses it.
5. Right-click with an empty hand to enable or disable the field.

The field repairs missing barrier blocks every two seconds, collapses if its Redstone Heart is
removed, cannot be mined in creative mode, has extreme explosion resistance, blocks Ender Pearls
physically, and rejects Chorus Fruit use near an active field.

## EMP breaching charge

The EMP is crafted with TNT in the center, four redstone dust on the cardinal sides, and four iron
ingots in the corners. It behaves as a stationary TNT-style charge with a four-second fuse and can
be primed by Redstone, flint and steel, a fire charge, or another explosion. Its pulse does not
damage terrain or entities: it only removes force-field blocks in a three-block spherical radius.
The projector remembers those breached positions for exactly 15 seconds and then immediately
restores the field. Ordinary mining and explosions still cannot break a force field.

The force-field model uses Minecraft's animated `misc/forcefield` texture, the same texture used by
the vanilla world border.

## Build

Use Java 21 and run `./gradlew build` after adding a standard Gradle 9 wrapper. The exact declared
toolchain is Minecraft 1.21.11, Yarn 1.21.11+build.4, Fabric Loader 0.18.4, and Fabric API
0.141.6+1.21.11.

The build also creates a named/deobfuscated development JAR and an API source ZIP for integrating
Redstone Hearts and EMP breaches into other mods. See `api/README.md` for the supported API surface.
