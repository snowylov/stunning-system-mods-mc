package com.noobvill.power;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.MapColor;
import net.minecraft.block.PistonBlock;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.block.piston.PistonBehavior;
import net.minecraft.component.type.AttributeModifierSlot;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.util.Identifier;
import net.minecraft.item.equipment.ArmorMaterial;
import net.minecraft.item.equipment.EquipmentType;
import net.minecraft.text.Text;

public final class ModContent {
    public static final Map<String, Item> ITEMS = new LinkedHashMap<>();
    public static final Map<String, Block> BLOCKS = new LinkedHashMap<>();

    public static final Block COMPRESSED_COAL = registerBlock("compressed_coal", Block::new,
            AbstractBlock.Settings.create().mapColor(MapColor.BLACK).strength(5.0F, 6.0F)
                    .sounds(BlockSoundGroup.METAL));
    public static final Block SUPER_COMPRESSED_COAL = registerBlock("super_compressed_coal", Block::new,
            AbstractBlock.Settings.create().mapColor(MapColor.BLACK).strength(10.0F, 12.0F)
                    .sounds(BlockSoundGroup.METAL));
    public static final Block ULTRA_COMPRESSED_COAL = registerBlock("ultra_compressed_coal", Block::new,
            AbstractBlock.Settings.create().mapColor(MapColor.BLACK).strength(20.0F, 24.0F)
                    .sounds(BlockSoundGroup.METAL));
    public static final Block REDSTONE_HEART = registerBlock("redstone_heart", Block::new,
            AbstractBlock.Settings.create().mapColor(MapColor.RED).strength(8.0F, 1200.0F)
                    .luminance(state -> 10).sounds(BlockSoundGroup.METAL));
    public static final PowerLampBlock ROSE_LAMP = registerLampBlock("rose_lamp", PowerLampBlock.Effect.NONE,
            "tooltip.noobvill_power.rose_lamp",
            AbstractBlock.Settings.create().mapColor(MapColor.PINK).strength(3.0F, 6.0F)
                    .luminance(state -> state.get(PowerLampBlock.POWERED) ? 15 : 7)
                    .sounds(BlockSoundGroup.GLASS));
    public static final PowerLampBlock LOVE_LAMP = registerLampBlock("love_lamp", PowerLampBlock.Effect.LOVE,
            "tooltip.noobvill_power.love_lamp",
            AbstractBlock.Settings.create().mapColor(MapColor.PINK).strength(3.0F, 6.0F)
                    .luminance(state -> state.get(PowerLampBlock.POWERED) ? 15 : 7)
                    .sounds(BlockSoundGroup.GLASS));
    public static final PowerLampBlock MOON = registerLampBlock("moon", PowerLampBlock.Effect.MOON,
            "tooltip.noobvill_power.moon",
            AbstractBlock.Settings.create().mapColor(MapColor.LIGHT_BLUE).strength(3.0F, 6.0F)
                    .luminance(state -> state.get(PowerLampBlock.POWERED) ? 15 : 7)
                    .sounds(BlockSoundGroup.GLASS));
    public static final PowerLampBlock HEALING_LAMP = registerLampBlock("healing_lamp", PowerLampBlock.Effect.HEALING,
            "tooltip.noobvill_power.healing_lamp",
            AbstractBlock.Settings.create().mapColor(MapColor.WHITE).strength(3.0F, 6.0F)
                    .luminance(state -> state.get(PowerLampBlock.POWERED) ? 15 : 7)
                    .sounds(BlockSoundGroup.GLASS));
    public static final PowerLampBlock SUN_LANTERN = registerLampBlock("sun_lantern", PowerLampBlock.Effect.NONE,
            "tooltip.noobvill_power.sun_lantern",
            AbstractBlock.Settings.create().mapColor(MapColor.YELLOW).strength(3.0F, 6.0F)
                    .luminance(state -> state.get(PowerLampBlock.POWERED) ? 15 : 7)
                    .sounds(BlockSoundGroup.GLASS));
    public static final Block FORCE_FIELD_PROJECTOR = registerBlock("force_field_projector",
            ForceFieldProjectorBlock::new,
            AbstractBlock.Settings.create().mapColor(MapColor.IRON_GRAY).strength(6.0F, 1200.0F)
                    .sounds(BlockSoundGroup.METAL));
    public static final EmpBlock EMP = registerBlock("emp", EmpBlock::new,
            AbstractBlock.Settings.copy(Blocks.TNT));
    public static final PistonBlock COBBLESTONE_PISTON = registerBlock("cobblestone_piston",
            settings -> new PistonBlock(false, settings),
            AbstractBlock.Settings.copy(Blocks.PISTON));
    public static final ForceFieldBlock FORCE_FIELD = registerBlockWithoutItem("force_field", ForceFieldBlock::new,
            AbstractBlock.Settings.create().mapColor(MapColor.LIGHT_BLUE).strength(-1.0F, 3_600_000.0F)
                    .dropsNothing().nonOpaque().allowsSpawning((state, world, pos, type) -> false)
                    .suffocates((state, world, pos) -> false).blockVision((state, world, pos) -> false)
                    .pistonBehavior(PistonBehavior.BLOCK));

    public static final Item INDUSTRIAL_DIAMOND = registerItem("industrial_diamond");
    public static final Item INDUSTRIAL_DIAMOND_DUST = registerItem("industrial_diamond_dust");
    public static final Item DIAMOND_DUST = registerItem("diamond_dust");
    public static final Item POWER_CRYSTAL = registerItem("power_crystal");
    public static final Item POWER_CRYSTAL_DUST = registerItem("power_crystal_dust");
    public static final Item INDUSTRIAL_POWER_CRYSTAL = registerItem("industrial_power_crystal");
    public static final Item INDUSTRIAL_POWER_CRYSTAL_DUST = registerItem("industrial_power_crystal_dust");

    public static final Item HAZMAT_MASK = registerHazmatArmor("hazmat_mask", ModArmorMaterials.HAZMAT_MASK,
            EquipmentType.HELMET,
            ModArmorMaterials.HAZMAT_MASK.createAttributeModifiers(EquipmentType.HELMET)
                    .with(ModAttributes.UNDERWATER_BREATHING,
                            modifier("hazmat_mask_underwater_breathing", 0.20,
                                    EntityAttributeModifier.Operation.ADD_VALUE),
                            AttributeModifierSlot.HEAD)
                    .with(ModAttributes.DARK_VISION,
                            modifier("hazmat_mask_dark_vision", 0.20,
                                    EntityAttributeModifier.Operation.ADD_VALUE),
                            AttributeModifierSlot.HEAD));
    public static final Item HAZMAT_SHIRT = registerHazmatArmor("hazmat_shirt", ModArmorMaterials.HAZMAT_SHIRT,
            EquipmentType.CHESTPLATE,
            ModArmorMaterials.HAZMAT_SHIRT.createAttributeModifiers(EquipmentType.CHESTPLATE)
                    .with(ModAttributes.HAZARD_IMMUNITY,
                            modifier("hazmat_shirt_hazard_immunity", 0.50,
                                    EntityAttributeModifier.Operation.ADD_VALUE),
                            AttributeModifierSlot.CHEST));
    public static final Item HAZMAT_PANTS = registerHazmatArmor("hazmat_pants", ModArmorMaterials.HAZMAT_PANTS,
            EquipmentType.LEGGINGS,
            ModArmorMaterials.HAZMAT_PANTS.createAttributeModifiers(EquipmentType.LEGGINGS)
                    .with(EntityAttributes.MOVEMENT_SPEED,
                            modifier("hazmat_pants_movement_speed", 0.11,
                                    EntityAttributeModifier.Operation.ADD_MULTIPLIED_BASE),
                            AttributeModifierSlot.LEGS)
                    .with(ModAttributes.HAZARD_IMMUNITY,
                            modifier("hazmat_pants_hazard_immunity", 0.50,
                                    EntityAttributeModifier.Operation.ADD_VALUE),
                            AttributeModifierSlot.LEGS));
    public static final Item RUBBER_BOOTS = registerHazmatArmor("rubber_boots", ModArmorMaterials.RUBBER_BOOTS,
            EquipmentType.BOOTS,
            ModArmorMaterials.RUBBER_BOOTS.createAttributeModifiers(EquipmentType.BOOTS)
                    .with(ModAttributes.FALL_DAMAGE_REDUCTION,
                            modifier("rubber_boots_fall_damage_reduction", 0.50,
                                    EntityAttributeModifier.Operation.ADD_VALUE),
                            AttributeModifierSlot.FEET));

    public static final Item MUSIC_T_SHIRT = registerLeatherArmor("music_t_shirt",
            ModArmorMaterials.MUSIC_T_SHIRT, EquipmentType.CHESTPLATE);
    public static final Item BASEBALL_T_SHIRT = registerLeatherArmor("baseball_t_shirt",
            ModArmorMaterials.BASEBALL_T_SHIRT, EquipmentType.CHESTPLATE);
    public static final Item T_SHIRT = registerLeatherArmor("t_shirt",
            ModArmorMaterials.T_SHIRT, EquipmentType.CHESTPLATE);
    public static final Item LEATHER_SHORTS = registerLeatherArmor("leather_shorts",
            ModArmorMaterials.LEATHER_SHORTS, EquipmentType.LEGGINGS);
    public static final Item SHORT_LEATHER_PANTS = registerLeatherArmor("short_leather_pants",
            ModArmorMaterials.SHORT_LEATHER_PANTS, EquipmentType.LEGGINGS);

    public static final List<Item> LEATHER_CLOTHING_ITEMS = List.of(
            MUSIC_T_SHIRT,
            BASEBALL_T_SHIRT,
            T_SHIRT,
            LEATHER_SHORTS,
            SHORT_LEATHER_PANTS);

    public static final Item CUBE_MODULE = registerItem("cube_module");
    public static final Item SPHERE_MODULE = registerItem("sphere_module");
    public static final Item CYLINDER_MODULE = registerItem("cylinder_module");
    public static final Item TUBE_MODULE = registerItem("tube_module");
    public static final Item SCALE_MODULE = registerItem("scale_module");
    public static final Item OFFSET_X_MODULE = registerItem("offset_x_module");
    public static final Item OFFSET_Y_MODULE = registerItem("offset_y_module");
    public static final Item OFFSET_Z_MODULE = registerItem("offset_z_module");

    private ModContent() {
    }

    public static void initialize() {
        Registry.register(Registries.ITEM_GROUP, NoobvillPower.id("leather_armor"), createLeatherArmorGroup());
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.REDSTONE).register(entries -> {
            BLOCKS.values().stream()
                    .filter(block -> block.asItem() != net.minecraft.item.Items.AIR)
                    .forEach(entries::add);
            ITEMS.values().stream()
                    .filter(item -> !(item instanceof BlockItem))
                    .filter(item -> !LEATHER_CLOTHING_ITEMS.contains(item))
                    .forEach(entries::add);
        });
    }

    private static ItemGroup createLeatherArmorGroup() {
        return FabricItemGroup.builder()
                .icon(() -> new ItemStack(BASEBALL_T_SHIRT))
                .displayName(Text.translatable("itemGroup.noobvill_power.leather_armor"))
                .entries((displayContext, entries) -> {
                    entries.add(Items.LEATHER_HELMET);
                    entries.add(Items.LEATHER_CHESTPLATE);
                    entries.add(Items.LEATHER_LEGGINGS);
                    entries.add(Items.LEATHER_BOOTS);
                    LEATHER_CLOTHING_ITEMS.forEach(entries::add);
                })
                .build();
    }

    private static Item registerItem(String name) {
        Identifier id = NoobvillPower.id(name);
        RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, id);
        Item item = new Item(new Item.Settings().registryKey(key));
        ITEMS.put(name, item);
        return Registry.register(Registries.ITEM, id, item);
    }

    private static Item registerHazmatArmor(String name, ArmorMaterial material, EquipmentType equipmentType,
            AttributeModifiersComponent modifiers) {
        Identifier id = NoobvillPower.id(name);
        RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, id);
        Item item = new HazmatArmorItem(new Item.Settings().registryKey(key)
                .armor(material, equipmentType)
                .attributeModifiers(modifiers));
        ITEMS.put(name, item);
        return Registry.register(Registries.ITEM, id, item);
    }

    private static Item registerLeatherArmor(String name, ArmorMaterial material, EquipmentType equipmentType) {
        Identifier id = NoobvillPower.id(name);
        RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, id);
        Item item = new Item(new Item.Settings().registryKey(key).armor(material, equipmentType));
        ITEMS.put(name, item);
        return Registry.register(Registries.ITEM, id, item);
    }

    private static EntityAttributeModifier modifier(String name, double value,
            EntityAttributeModifier.Operation operation) {
        return new EntityAttributeModifier(NoobvillPower.id(name), value, operation);
    }

    private static <T extends Block> T registerBlock(String name, Function<AbstractBlock.Settings, T> factory,
            AbstractBlock.Settings settings) {
        Identifier id = NoobvillPower.id(name);
        RegistryKey<Block> blockKey = RegistryKey.of(RegistryKeys.BLOCK, id);
        T block = factory.apply(settings.registryKey(blockKey));
        BLOCKS.put(name, block);
        Registry.register(Registries.BLOCK, id, block);

        RegistryKey<Item> itemKey = RegistryKey.of(RegistryKeys.ITEM, id);
        BlockItem item = new BlockItem(block, new Item.Settings().registryKey(itemKey).useBlockPrefixedTranslationKey());
        ITEMS.put(name, item);
        Registry.register(Registries.ITEM, id, item);
        return block;
    }

    private static PowerLampBlock registerLampBlock(String name, PowerLampBlock.Effect effect,
            String tooltipKey, AbstractBlock.Settings settings) {
        Identifier id = NoobvillPower.id(name);
        RegistryKey<Block> blockKey = RegistryKey.of(RegistryKeys.BLOCK, id);
        PowerLampBlock block = new PowerLampBlock(settings.registryKey(blockKey), effect);
        BLOCKS.put(name, block);
        Registry.register(Registries.BLOCK, id, block);

        RegistryKey<Item> itemKey = RegistryKey.of(RegistryKeys.ITEM, id);
        LampBlockItem item = new LampBlockItem(block,
                new Item.Settings().registryKey(itemKey).useBlockPrefixedTranslationKey(), tooltipKey);
        ITEMS.put(name, item);
        Registry.register(Registries.ITEM, id, item);
        return block;
    }

    private static <T extends Block> T registerBlockWithoutItem(String name,
            Function<AbstractBlock.Settings, T> factory, AbstractBlock.Settings settings) {
        Identifier id = NoobvillPower.id(name);
        RegistryKey<Block> key = RegistryKey.of(RegistryKeys.BLOCK, id);
        T block = factory.apply(settings.registryKey(key));
        BLOCKS.put(name, block);
        return Registry.register(Registries.BLOCK, id, block);
    }
}
