# Noobvill Power API 1.8.1

This source API exposes stable integration points for the Redstone Heart and EMP in Fabric 1.21.11.
The full deobfuscated JAR is the compile-time dependency; the normal remapped JAR is required at runtime.

## Gradle development dependency

Place the deobfuscated JAR in your mod's `libs` directory:

```groovy
dependencies {
    modCompileOnly files('libs/noobvill-power-forcefields-1.8.1-deobf.jar')
    modLocalRuntime files('libs/noobvill-power-forcefields-1.8.1.jar')
}
```

Add the runtime mod as a dependency in `fabric.mod.json`:

```json
{
  "depends": {
    "noobvill_power": ">=1.8.1"
  }
}
```

## Common tags

- `#c:redstone_hearts` for Redstone Heart blocks and items.
- `#c:emps` for EMP blocks and items.

## Java examples

```java
import com.noobvill.power.api.PowerContentApi;

boolean powered = PowerContentApi.hasRedstoneHeart(world, machinePos, 3);
boolean isEmpStack = PowerContentApi.isEmp(stack);

// Server side only: standard three-block radius, 15-second breach.
PowerContentApi.triggerEmpBreach(serverWorld, impactPos);

// Server side only: custom radius and duration in ticks.
PowerContentApi.triggerEmpBreach(serverWorld, impactPos, 5, 200);
```

Use the API methods and common tags rather than importing `ModContent`. That keeps integrations compatible
if the internal registry implementation changes later.
