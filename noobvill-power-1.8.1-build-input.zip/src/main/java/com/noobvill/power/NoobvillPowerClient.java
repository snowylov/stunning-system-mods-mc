package com.noobvill.power;

import com.noobvill.power.client.WetsuitFeatureRenderer;
import com.noobvill.power.client.SkinCustomizationScreen;
import java.util.Comparator;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.render.BlockRenderLayer;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.text.Text;

public final class NoobvillPowerClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        BlockRenderLayerMap.putBlock(ModContent.FORCE_FIELD, BlockRenderLayer.TRANSLUCENT);
        registerSkinCustomizationButton();
        LivingEntityFeatureRendererRegistrationCallback.EVENT.register(
                (entityType, entityRenderer, registrationHelper, context) -> {
                    if (entityRenderer instanceof PlayerEntityRenderer playerRenderer) {
                        registrationHelper.register(new WetsuitFeatureRenderer(playerRenderer));
                    }
                });
    }

    private static void registerSkinCustomizationButton() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (!(screen instanceof GameMenuScreen)) {
                return;
            }

            ClickableWidget exitButton = Screens.getButtons(screen).stream()
                    .filter(button -> isExitButton(button.getMessage()))
                    .findFirst()
                    .orElseGet(() -> Screens.getButtons(screen).stream()
                            .filter(button -> button.getWidth() >= 180)
                            .max(Comparator.comparingInt(ClickableWidget::getY))
                            .orElse(null));
            if (exitButton == null) {
                NoobvillPower.LOGGER.warn("Could not find the pause-menu exit button for Skin Customization");
                return;
            }

            Screens.getButtons(screen).add(ButtonWidget.builder(Text.literal("❄"), button ->
                            client.setScreen(new SkinCustomizationScreen(screen)))
                    .tooltip(Tooltip.of(Text.translatable("button.noobvill_power.skin_customization")))
                    .dimensions(Math.max(4, exitButton.getX() - 24), exitButton.getY(), 20, 20)
                    .build());
        });
    }

    private static boolean isExitButton(Text message) {
        String label = message.getString();
        return label.equals(Text.translatable("menu.returnToMenu").getString())
                || label.equals(Text.translatable("menu.disconnect").getString());
    }
}
