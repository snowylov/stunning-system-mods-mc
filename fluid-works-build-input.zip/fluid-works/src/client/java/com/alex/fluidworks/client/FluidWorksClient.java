package com.alex.fluidworks.client;

import com.alex.fluidworks.FluidWorks;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.entity.EmptyEntityRenderer;
import net.minecraft.client.render.entity.FlyingItemEntityRenderer;

public final class FluidWorksClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // 1.21.11 derives the material pipeline from the baked block model.
        EntityRendererRegistry.register(FluidWorks.UNIVERSAL_FLUID_POTION_ENTITY,
            FlyingItemEntityRenderer::new);
        EntityRendererRegistry.register(FluidWorks.LINGERING_FLUID_MARKER_ENTITY,
            EmptyEntityRenderer::new);
    }
}
