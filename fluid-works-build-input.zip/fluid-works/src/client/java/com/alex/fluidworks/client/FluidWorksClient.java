package com.alex.fluidworks.client;

import com.alex.fluidworks.FluidWorks;
import dev.liquidfabric.api.unofficial.client.UtilityItemColorProviders;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.minecraft.client.render.RenderLayer;

public final class FluidWorksClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        BlockRenderLayerMap.INSTANCE.putBlocks(RenderLayer.getTranslucent(),
            FluidWorks.DOUBLE_SMELTED_GLASS, FluidWorks.RESERVOIR_WINDOW);
        UtilityItemColorProviders.registerOverlayItem(FluidWorks.FUEL_CELL, 1);
    }
}
