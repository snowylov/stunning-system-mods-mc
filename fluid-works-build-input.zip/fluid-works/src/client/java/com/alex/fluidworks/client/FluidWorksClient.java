package com.alex.fluidworks.client;

import net.fabricmc.api.ClientModInitializer;

public final class FluidWorksClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // 1.21.11 derives the material pipeline from the baked block model.
    }
}
