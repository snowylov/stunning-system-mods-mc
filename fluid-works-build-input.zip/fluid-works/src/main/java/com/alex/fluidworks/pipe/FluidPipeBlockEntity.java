package com.alex.fluidworks.pipe;

import com.alex.fluidworks.FluidWorks;
import com.alex.fluidworks.fluid.FluidWorksStorage;
import dev.liquidfabric.api.unofficial.api.block.FluidStorageBlockEntity;
import dev.liquidfabric.api.unofficial.api.transfer.FluidTransferHelper;
import dev.liquidfabric.api.unofficial.core.FluidUnits;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidStorage;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.Fluids;
import net.minecraft.registry.Registries;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.storage.ReadView;
import net.minecraft.storage.WriteView;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

/**
 * Buffered pipe endpoint. The one-bucket buffer prevents duplication and gives
 * future pipe tiers a stable transfer-rate and redstone-control contract.
 */
public final class FluidPipeBlockEntity extends BlockEntity implements FluidStorageBlockEntity {
    private static final long BUFFER_CAPACITY = FluidUnits.BUCKET_DROPLETS;
    private final FluidWorksStorage storage = new FluidWorksStorage(this, BUFFER_CAPACITY);
    private int sideCursor;

    public FluidPipeBlockEntity(BlockPos pos, BlockState state) {
        super(FluidWorks.FLUID_PIPE_BLOCK_ENTITY, pos, state);
    }

    public FluidWorksStorage storage() {
        return storage;
    }

    public static void serverTick(World world, BlockPos pos, BlockState state,
                                  FluidPipeBlockEntity pipe) {
        if (!(world instanceof ServerWorld serverWorld)) return;
        if (!(state.getBlock() instanceof FluidPipeBlock block) || !state.get(FluidPipeBlock.ENABLED)) return;
        if (!state.get(FluidPipeBlock.REDSTONE_MODE).permits(serverWorld.isReceivingRedstonePower(pos))) return;

        long remaining = block.transferRate();
        Direction pulledFrom = null;

        if (pipe.storage.amountView() <= 0) {
            for (int i = 0; i < Direction.values().length; i++) {
                Direction side = Direction.values()[(pipe.sideCursor + i) % Direction.values().length];
                Storage<FluidVariant> adjacent = adjacent(serverWorld, pos, side);
                long moved = FluidTransferHelper.tryMove(adjacent, pipe.storage, remaining);
                if (moved > 0) {
                    pulledFrom = side;
                    remaining -= moved;
                    break;
                }
            }
        }

        long outputBudget = block.transferRate();
        for (int i = 0; i < Direction.values().length && outputBudget > 0; i++) {
            Direction side = Direction.values()[(pipe.sideCursor + i + 1) % Direction.values().length];
            if (side == pulledFrom) continue;
            Storage<FluidVariant> adjacent = adjacent(serverWorld, pos, side);
            long moved = FluidTransferHelper.tryMove(pipe.storage, adjacent, outputBudget);
            outputBudget -= moved;
        }
        pipe.sideCursor = (pipe.sideCursor + 1) % Direction.values().length;
    }

    private static Storage<FluidVariant> adjacent(ServerWorld world, BlockPos pos, Direction side) {
        return FluidStorage.SIDED.find(world, pos.offset(side), side.getOpposite());
    }

    @Override
    public Storage<FluidVariant> liquidFabricStorage() {
        return storage;
    }

    @Override
    protected void readData(ReadView view) {
        super.readData(view);
        sideCursor = Math.floorMod(view.getInt("SideCursor", 0), Direction.values().length);
        Identifier id = Identifier.tryParse(view.getString("FluidId", "minecraft:empty"));
        Fluid fluid = id == null ? Fluids.EMPTY : Registries.FLUID.get(id);
        storage.load(fluid == null || fluid == Fluids.EMPTY ? FluidVariant.blank() : FluidVariant.of(fluid),
            view.getLong("FluidAmount", 0));
    }

    @Override
    protected void writeData(WriteView view) {
        super.writeData(view);
        view.putInt("SideCursor", sideCursor);
        if (!storage.variantView().isBlank() && storage.amountView() > 0) {
            view.putString("FluidId", Registries.FLUID.getId(storage.variantView().getFluid()).toString());
            view.putLong("FluidAmount", storage.amountView());
        }
    }
}
