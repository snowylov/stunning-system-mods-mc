package com.alex.fluidworks.device;

import com.alex.fluidworks.FluidWorks;
import com.mojang.serialization.MapCodec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityTicker;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import dev.liquidfabric.api.unofficial.helper.item.FluidItemComponentHelper;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/** One directional block implementation shared by the purpose-built fluid machines. */
public final class FluidDeviceBlock extends BlockWithEntity {
    public static final EnumProperty<Direction> FACING = Properties.FACING;
    public static final BooleanProperty ENABLED = BooleanProperty.of("enabled");

    private final FluidDeviceKind kind;
    private final MapCodec<FluidDeviceBlock> codec = MapCodec.unit(this);

    public FluidDeviceBlock(FluidDeviceKind kind, Settings settings) {
        super(settings);
        this.kind = kind;
        setDefaultState(getDefaultState().with(FACING, Direction.NORTH).with(ENABLED, true));
    }

    public FluidDeviceKind kind() {
        return kind;
    }

    @Override
    protected MapCodec<? extends BlockWithEntity> getCodec() {
        return codec;
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(FACING, ENABLED);
    }

    @Override
    public BlockState getPlacementState(ItemPlacementContext context) {
        return getDefaultState().with(FACING, context.getSide());
    }

    @Override
    protected BlockState rotate(BlockState state, BlockRotation rotation) {
        return state.with(FACING, rotation.rotate(state.get(FACING)));
    }

    @Override
    protected BlockState mirror(BlockState state, BlockMirror mirror) {
        return rotate(state, mirror.getRotation(state.get(FACING)));
    }

    @Override
    protected BlockRenderType getRenderType(BlockState state) {
        return BlockRenderType.MODEL;
    }

    @Override
    protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos,
                                         ShapeContext context) {
        Direction facing = state.get(FACING);
        return switch (kind.shapeFamily()) {
            case TRAY, GRATE -> VoxelShapes.union(backPlate(facing, 3), rim(facing));
            case SENSOR, COVER -> backPlate(facing, 3);
            case NOZZLE -> VoxelShapes.union(backPlate(facing, 3), tube(facing, 3, 13, 6, 10));
            case CANNON -> VoxelShapes.union(core(), tube(facing, 0, 16, 5, 11));
            case INTAKE -> VoxelShapes.union(backPlate(facing, 4), tube(facing, 4, 12, 4, 12));
            case VALVE -> VoxelShapes.union(core(), tube(facing, 0, 16, 5, 11));
            case ROUTER -> VoxelShapes.union(core(), tube(facing, 0, 16, 5, 11), crossTube(facing));
            case EXCHANGER -> VoxelShapes.union(core(), tube(facing, 0, 16, 4, 7),
                tube(facing, 0, 16, 9, 12));
            case TRAP -> VoxelShapes.union(backPlate(facing, 4), tube(facing, 4, 14, 5, 11));
            case LINK -> VoxelShapes.union(core(), tube(facing, 1, 15, 6, 10));
        };
    }

    @Override
    public @Nullable BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
        return new FluidDeviceBlockEntity(pos, state);
    }

    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(World world, BlockState state,
                                                                  BlockEntityType<T> type) {
        return world.isClient() ? null : validateTicker(type, FluidWorks.FLUID_DEVICE_BLOCK_ENTITY,
            FluidDeviceBlockEntity::serverTick);
    }

    @Override
    protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player,
                                 BlockHitResult hit) {
        if (!world.isClient()) {
            if (player.isSneaking() && world.getBlockEntity(pos) instanceof FluidDeviceBlockEntity device) {
                player.sendMessage(device.statusText(), true);
            } else {
                boolean enabled = !state.get(ENABLED);
                world.setBlockState(pos, state.with(ENABLED, enabled), Block.NOTIFY_ALL);
                player.sendMessage(Text.translatable(enabled
                    ? "message.fluidworks.device.enabled" : "message.fluidworks.device.disabled"), true);
            }
        }
        return ActionResult.SUCCESS;
    }

    @Override
    protected ActionResult onUseWithItem(ItemStack stack, BlockState state, World world, BlockPos pos,
                                         PlayerEntity player, Hand hand, BlockHitResult hit) {
        if (!(world.getBlockEntity(pos) instanceof FluidDeviceBlockEntity device)) return ActionResult.PASS;
        if (kind == FluidDeviceKind.FLUID_SEPARATOR && FluidItemComponentHelper.hasFluid(stack)
            && (world.isClient() || device.setFilterFrom(stack))) {
            if (!world.isClient()) player.sendMessage(device.statusText(), true);
            return ActionResult.SUCCESS;
        }
        return ActionResult.PASS;
    }

    @Override
    protected boolean hasComparatorOutput(BlockState state) {
        return true;
    }

    @Override
    protected int getComparatorOutput(BlockState state, World world, BlockPos pos, Direction direction) {
        return world.getBlockEntity(pos) instanceof FluidDeviceBlockEntity device
            ? device.comparatorOutput(world, pos, state) : 0;
    }

    private static VoxelShape core() {
        return createCuboidShape(3, 3, 3, 13, 13, 13);
    }

    private static VoxelShape tube(Direction direction, double alongMin, double alongMax,
                                   double crossMin, double crossMax) {
        return switch (direction.getAxis()) {
            case X -> createCuboidShape(alongMin, crossMin, crossMin, alongMax, crossMax, crossMax);
            case Y -> createCuboidShape(crossMin, alongMin, crossMin, crossMax, alongMax, crossMax);
            case Z -> createCuboidShape(crossMin, crossMin, alongMin, crossMax, crossMax, alongMax);
        };
    }

    private static VoxelShape crossTube(Direction facing) {
        return switch (facing.getAxis()) {
            case X -> createCuboidShape(5, 0, 5, 11, 16, 11);
            case Y -> createCuboidShape(0, 5, 5, 16, 11, 11);
            case Z -> createCuboidShape(0, 5, 5, 16, 11, 11);
        };
    }

    private static VoxelShape backPlate(Direction facing, double depth) {
        return switch (facing) {
            case NORTH -> createCuboidShape(1, 1, 16 - depth, 15, 15, 16);
            case SOUTH -> createCuboidShape(1, 1, 0, 15, 15, depth);
            case WEST -> createCuboidShape(16 - depth, 1, 1, 16, 15, 15);
            case EAST -> createCuboidShape(0, 1, 1, depth, 15, 15);
            case UP -> createCuboidShape(1, 0, 1, 15, depth, 15);
            case DOWN -> createCuboidShape(1, 16 - depth, 1, 15, 16, 15);
        };
    }

    private static VoxelShape rim(Direction facing) {
        VoxelShape plate = backPlate(facing, 4);
        return VoxelShapes.union(plate, tube(facing, 3, 6, 1, 3), tube(facing, 3, 6, 13, 15));
    }
}
