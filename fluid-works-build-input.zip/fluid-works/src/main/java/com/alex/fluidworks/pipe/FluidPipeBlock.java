package com.alex.fluidworks.pipe;

import com.alex.fluidworks.FluidWorks;
import com.mojang.serialization.MapCodec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityTicker;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public final class FluidPipeBlock extends BlockWithEntity {
    public static final BooleanProperty ENABLED = BooleanProperty.of("enabled");
    public static final EnumProperty<PipeRedstoneMode> REDSTONE_MODE =
        EnumProperty.of("redstone_mode", PipeRedstoneMode.class);

    private static final VoxelShape SHAPE = VoxelShapes.union(
        createCuboidShape(5, 5, 5, 11, 11, 11),
        createCuboidShape(5, 5, 0, 11, 11, 16),
        createCuboidShape(0, 5, 5, 16, 11, 11),
        createCuboidShape(5, 0, 5, 11, 16, 11));

    private final long transferRate;
    private final PipeRedstoneMode defaultMode;
    private final MapCodec<FluidPipeBlock> codec = MapCodec.unit(this);

    public FluidPipeBlock(long transferRate, PipeRedstoneMode defaultMode, Settings settings) {
        super(settings);
        this.transferRate = transferRate;
        this.defaultMode = defaultMode;
        setDefaultState(getDefaultState().with(ENABLED, true).with(REDSTONE_MODE, defaultMode));
    }

    public long transferRate() {
        return transferRate;
    }

    public PipeRedstoneMode defaultMode() {
        return defaultMode;
    }

    @Override
    protected MapCodec<? extends BlockWithEntity> getCodec() {
        return codec;
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(ENABLED, REDSTONE_MODE);
    }

    @Override
    protected BlockRenderType getRenderType(BlockState state) {
        return BlockRenderType.MODEL;
    }

    @Override
    protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
        return SHAPE;
    }

    @Override
    public @Nullable BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
        return new FluidPipeBlockEntity(pos, state);
    }

    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(World world, BlockState state,
                                                                  BlockEntityType<T> type) {
        return world.isClient() ? null
            : validateTicker(type, FluidWorks.FLUID_PIPE_BLOCK_ENTITY, FluidPipeBlockEntity::serverTick);
    }

    @Override
    protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player,
                                 BlockHitResult hit) {
        if (!world.isClient()) {
            if (player.isSneaking()) {
                PipeRedstoneMode next = state.get(REDSTONE_MODE).next();
                world.setBlockState(pos, state.with(REDSTONE_MODE, next), Block.NOTIFY_ALL);
                player.sendMessage(Text.translatable("message.fluidworks.pipe.mode", next.asString()), true);
            } else {
                boolean enabled = !state.get(ENABLED);
                world.setBlockState(pos, state.with(ENABLED, enabled), Block.NOTIFY_ALL);
                player.sendMessage(Text.translatable(enabled
                    ? "message.fluidworks.pipe.enabled" : "message.fluidworks.pipe.disabled"), true);
            }
        }
        return ActionResult.SUCCESS;
    }

    @Override
    protected boolean hasComparatorOutput(BlockState state) {
        return true;
    }

    @Override
    protected int getComparatorOutput(BlockState state, World world, BlockPos pos, Direction direction) {
        return world.getBlockEntity(pos) instanceof FluidPipeBlockEntity pipe
            ? pipe.storage().comparatorOutput() : 0;
    }
}
