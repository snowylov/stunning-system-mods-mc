package com.alex.fluidworks;

import com.alex.fluidworks.block.RetainingTankBlockItem;
import com.alex.fluidworks.block.TankBlock;
import com.alex.fluidworks.block.TankBlockEntity;
import com.alex.fluidworks.item.FuelCellItem;
import com.alex.fluidworks.reservoir.ReservoirCasingBlock;
import com.alex.fluidworks.reservoir.ReservoirControllerBlock;
import com.alex.fluidworks.reservoir.ReservoirControllerBlockEntity;
import com.alex.fluidworks.reservoir.ReservoirTier;
import com.alex.fluidworks.reservoir.ReservoirValveBlock;
import com.alex.fluidworks.reservoir.ReservoirValveBlockEntity;
import com.alex.fluidworks.reservoir.ReservoirWindowBlock;
import dev.liquidfabric.api.unofficial.api.block.BlockFluidContainerDefinition;
import dev.liquidfabric.api.unofficial.api.container.FluidContainerDefinition;
import dev.liquidfabric.api.unofficial.core.FluidUnits;
import dev.liquidfabric.api.unofficial.core.UtilityApiRegistries;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.Map;

public final class FluidWorks implements ModInitializer {
    public static final String MOD_ID = "fluidworks";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static TankBlock TANK;
    public static TankBlock RESERVOIR_TANK;
    public static Block DOUBLE_SMELTED_GLASS;
    public static ReservoirWindowBlock RESERVOIR_WINDOW;
    public static FuelCellItem FUEL_CELL;

    public static final Map<ReservoirTier, ReservoirCasingBlock> CASINGS = new EnumMap<>(ReservoirTier.class);
    public static final Map<ReservoirTier, ReservoirControllerBlock> CONTROLLERS = new EnumMap<>(ReservoirTier.class);
    public static final Map<ReservoirTier, ReservoirValveBlock> VALVES = new EnumMap<>(ReservoirTier.class);
    private static final Map<Identifier, Item> CONTENT_ITEMS = new LinkedHashMap<>();

    public static BlockEntityType<TankBlockEntity> TANK_BLOCK_ENTITY;
    public static BlockEntityType<ReservoirControllerBlockEntity> RESERVOIR_CONTROLLER_BLOCK_ENTITY;
    public static BlockEntityType<ReservoirValveBlockEntity> RESERVOIR_VALVE_BLOCK_ENTITY;
    public static ItemGroup FLUID_WORKS_TAB;

    @Override
    public void onInitialize() {
        registerBaseContent();
        registerReservoirContent();
        registerBlockEntities();
        registerFluidHooks();
        registerItemGroup();
        LOGGER.info("Fluid Works initialized with independent Easy Containers API support");
    }

    private static void registerBaseContent() {
        TANK = registerTank("tank", FluidUnits.bucketsToDroplets(16), false,
            AbstractBlock.Settings.copy(Blocks.IRON_BLOCK));
        RESERVOIR_TANK = registerTank("reservoir_tank", FluidUnits.mbToDroplets(12), true,
            AbstractBlock.Settings.copy(Blocks.IRON_BLOCK).nonOpaque());

        DOUBLE_SMELTED_GLASS = registerSimpleBlock("double_smelted_glass",
            new Block(settingsFor("double_smelted_glass", AbstractBlock.Settings.copy(Blocks.GLASS).nonOpaque())));
        RESERVOIR_WINDOW = (ReservoirWindowBlock) registerSimpleBlock("reservoir_window",
            new ReservoirWindowBlock(settingsFor("reservoir_window",
                AbstractBlock.Settings.copy(Blocks.GLASS).strength(2.0F, 6.0F).nonOpaque())));

        Identifier fuelCellId = id("fuel_cell");
        RegistryKey<Item> fuelCellKey = RegistryKey.of(Registries.ITEM.getKey(), fuelCellId);
        FUEL_CELL = Registry.register(Registries.ITEM, fuelCellKey,
            new FuelCellItem(new Item.Settings().registryKey(fuelCellKey), FluidUnits.mbToDroplets(500)));
        CONTENT_ITEMS.put(fuelCellId, FUEL_CELL);
        UtilityApiRegistries.registerCustomFluidContainerItem(fuelCellId, FUEL_CELL,
            FluidContainerDefinition.custom(FluidUnits.mbToDroplets(500), false, 1, fluidId -> true));
    }

    private static void registerReservoirContent() {
        for (ReservoirTier tier : ReservoirTier.values()) {
            String prefix = tier.id() + "_reservoir_";
            ReservoirCasingBlock casing = (ReservoirCasingBlock) registerSimpleBlock(prefix + "casing",
                new ReservoirCasingBlock(tier, settingsFor(prefix + "casing",
                    AbstractBlock.Settings.copy(tier.materialBlock()).strength(
                        tier == ReservoirTier.NETHERITE ? 50.0F : 5.0F,
                        tier == ReservoirTier.NETHERITE ? 1200.0F : 12.0F))));
            CASINGS.put(tier, casing);

            ReservoirControllerBlock controller = (ReservoirControllerBlock) registerSimpleBlock(prefix + "controller",
                new ReservoirControllerBlock(tier, settingsFor(prefix + "controller",
                    AbstractBlock.Settings.copy(tier.materialBlock()))));
            CONTROLLERS.put(tier, controller);

            ReservoirValveBlock valve = (ReservoirValveBlock) registerSimpleBlock(prefix + "valve",
                new ReservoirValveBlock(tier, settingsFor(prefix + "valve",
                    AbstractBlock.Settings.copy(tier.materialBlock()))));
            VALVES.put(tier, valve);
        }
    }

    private static void registerBlockEntities() {
        TANK_BLOCK_ENTITY = Registry.register(Registries.BLOCK_ENTITY_TYPE, id("tank"),
            FabricBlockEntityTypeBuilder.create(TankBlockEntity::new, TANK, RESERVOIR_TANK).build());
        RESERVOIR_CONTROLLER_BLOCK_ENTITY = Registry.register(Registries.BLOCK_ENTITY_TYPE,
            id("reservoir_controller"), FabricBlockEntityTypeBuilder.create(
                ReservoirControllerBlockEntity::new, CONTROLLERS.values().toArray(Block[]::new)).build());
        RESERVOIR_VALVE_BLOCK_ENTITY = Registry.register(Registries.BLOCK_ENTITY_TYPE,
            id("reservoir_valve"), FabricBlockEntityTypeBuilder.create(
                ReservoirValveBlockEntity::new, VALVES.values().toArray(Block[]::new)).build());
    }

    private static void registerFluidHooks() {
        UtilityApiRegistries.registerFluidStorage(TANK_BLOCK_ENTITY,
            (tank, side) -> tank.liquidFabricStorage());
        UtilityApiRegistries.registerFluidStorage(RESERVOIR_CONTROLLER_BLOCK_ENTITY,
            (controller, side) -> controller.liquidFabricStorage());
        UtilityApiRegistries.registerFluidStorage(RESERVOIR_VALVE_BLOCK_ENTITY,
            (valve, side) -> valve.liquidFabricStorage());

        UtilityApiRegistries.registerFluidContainerBlock(id("tank"), TANK,
            new BlockFluidContainerDefinition(FluidUnits.bucketsToDroplets(16),
                BlockFluidContainerDefinition.Bounds.fullBlockInset(), fluidId -> true),
            (blockEntity, side) -> ((TankBlockEntity) blockEntity).liquidFabricStorage());
        UtilityApiRegistries.registerFluidContainerBlock(id("reservoir_tank"), RESERVOIR_TANK,
            new BlockFluidContainerDefinition(FluidUnits.mbToDroplets(12),
                new BlockFluidContainerDefinition.Bounds(1 / 16F, 0.001F, 1 / 16F,
                    15 / 16F, 0.999F, 15 / 16F), fluidId -> true),
            (blockEntity, side) -> ((TankBlockEntity) blockEntity).liquidFabricStorage());

        long maximumMultiblockCapacity = 9L * 9L * 9L
            * ReservoirTier.NETHERITE.dropletsPerInteriorBlock();
        for (ReservoirTier tier : ReservoirTier.values()) {
            UtilityApiRegistries.registerFluidContainerBlock(id(tier.id() + "_reservoir_controller"),
                CONTROLLERS.get(tier), new BlockFluidContainerDefinition(maximumMultiblockCapacity,
                    BlockFluidContainerDefinition.Bounds.fullBlockInset(), fluidId -> true),
                (blockEntity, side) -> ((ReservoirControllerBlockEntity) blockEntity).liquidFabricStorage());
            UtilityApiRegistries.registerFluidContainerBlock(id(tier.id() + "_reservoir_valve"),
                VALVES.get(tier), new BlockFluidContainerDefinition(maximumMultiblockCapacity,
                    BlockFluidContainerDefinition.Bounds.fullBlockInset(), fluidId -> true),
                (blockEntity, side) -> ((ReservoirValveBlockEntity) blockEntity).liquidFabricStorage());
        }
    }

    private static TankBlock registerTank(String path, long capacity, boolean retainsFluid,
                                          AbstractBlock.Settings settings) {
        Identifier id = id(path);
        RegistryKey<Block> blockKey = RegistryKey.of(Registries.BLOCK.getKey(), id);
        TankBlock block = Registry.register(Registries.BLOCK, blockKey,
            new TankBlock(settings.registryKey(blockKey).pistonBehavior(net.minecraft.block.piston.PistonBehavior.BLOCK),
                capacity, retainsFluid));

        RegistryKey<Item> itemKey = RegistryKey.of(Registries.ITEM.getKey(), id);
        Item item = retainsFluid
            ? new RetainingTankBlockItem(block,
                new Item.Settings().registryKey(itemKey).useBlockPrefixedTranslationKey().maxCount(1))
            : new BlockItem(block,
                new Item.Settings().registryKey(itemKey).useBlockPrefixedTranslationKey());
        Registry.register(Registries.ITEM, itemKey, item);
        CONTENT_ITEMS.put(id, item);

        if (retainsFluid) {
            UtilityApiRegistries.registerCustomFluidContainerItem(id, item,
                FluidContainerDefinition.custom(capacity, false, 1, fluidId -> true));
        }
        return block;
    }

    private static Block registerSimpleBlock(String path, Block block) {
        Identifier id = id(path);
        Registry.register(Registries.BLOCK, id, block);
        RegistryKey<Item> itemKey = RegistryKey.of(Registries.ITEM.getKey(), id);
        Item item = Registry.register(Registries.ITEM, itemKey,
            new BlockItem(block, new Item.Settings().registryKey(itemKey).useBlockPrefixedTranslationKey()));
        CONTENT_ITEMS.put(id, item);
        return block;
    }

    private static AbstractBlock.Settings settingsFor(String path, AbstractBlock.Settings settings) {
        RegistryKey<Block> key = RegistryKey.of(Registries.BLOCK.getKey(), id(path));
        return settings.registryKey(key);
    }

    private static void registerItemGroup() {
        RegistryKey<ItemGroup> key = RegistryKey.of(Registries.ITEM_GROUP.getKey(), id("fluid_works"));
        FLUID_WORKS_TAB = Registry.register(Registries.ITEM_GROUP, key,
            FabricItemGroup.builder()
                .displayName(Text.translatable("itemGroup.fluidworks.fluid_works"))
                .icon(() -> new ItemStack(TANK))
                .entries((context, entries) -> CONTENT_ITEMS.values().forEach(entries::add))
                .build());
    }

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }
}
