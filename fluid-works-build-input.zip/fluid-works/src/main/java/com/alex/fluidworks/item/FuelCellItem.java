package com.alex.fluidworks.item;

import dev.liquidfabric.api.unofficial.liquid.BaseLiquidContainerItem;

/** A non-drinkable, reusable 500 mB component-backed fluid container. */
public final class FuelCellItem extends BaseLiquidContainerItem {
    public FuelCellItem(Settings settings, long capacityDroplets) {
        super(settings.maxCount(1), capacityDroplets, false, false, 1,
            false, 0, 1.0D, 0);
    }
}
