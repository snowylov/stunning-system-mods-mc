package com.alex.fluidworks.pipe;

import dev.liquidfabric.api.unofficial.core.FluidUnits;

/** Defines transfer behavior without creating a separate block entity type per pipe. */
public enum PipeKind {
    STANDARD(50, 1, PipeRedstoneMode.ALWAYS),
    REDSTONE_VALVE(50, 1, PipeRedstoneMode.SIGNAL_HIGH),
    EXTRACTION(250, 1, PipeRedstoneMode.SIGNAL_HIGH),
    HIGH_PRESSURE(1_000, 4, PipeRedstoneMode.ALWAYS),
    METER(250, 1, PipeRedstoneMode.ALWAYS),
    OVERFLOW(250, 1, PipeRedstoneMode.ALWAYS),
    PULSE(250, 1, PipeRedstoneMode.SIGNAL_HIGH),
    PRIORITY(250, 1, PipeRedstoneMode.ALWAYS),
    DIODE(250, 1, PipeRedstoneMode.ALWAYS),
    FILTER(250, 1, PipeRedstoneMode.ALWAYS),
    MIXING(250, 4, PipeRedstoneMode.ALWAYS);

    private final long transferRate;
    private final long bufferCapacity;
    private final PipeRedstoneMode defaultRedstoneMode;

    PipeKind(long transferRateMb, long bufferBuckets, PipeRedstoneMode defaultRedstoneMode) {
        this.transferRate = FluidUnits.mbToDroplets(transferRateMb);
        this.bufferCapacity = FluidUnits.bucketsToDroplets(bufferBuckets);
        this.defaultRedstoneMode = defaultRedstoneMode;
    }

    public long transferRate() {
        return transferRate;
    }

    public long bufferCapacity() {
        return bufferCapacity;
    }

    public PipeRedstoneMode defaultRedstoneMode() {
        return defaultRedstoneMode;
    }

    public boolean directional() {
        return this == EXTRACTION || this == DIODE || this == PULSE;
    }
}
