# Fluid Works

Fluid Works is a Fabric 1.21.11 industrial fluid-storage mod. It requires the
independent **Fabric Fluid API Easy Containers 1.3.0** mod at compile time and
runtime. The dependency is not embedded or shaded into Fluid Works.

## Content

- Tank: 16 buckets, full-cube industrial tank.
- Reservoir Tank: 12 mB, 14-pixel-wide retained portable tank.
- Fuel Cell: 500 mB portable API container with a fluid-tinted overlay.
- Double Smelted Glass and Reservoir Window.
- Copper, iron, gold, and netherite reservoir casings, controllers, and valves.
- Hollow 3×3×3 through 11×11×11 multiblock reservoirs.
- Observation Window and persistent Fluid Label attachments.
- Bucket and Bottle Dispensers with four-bucket internal buffers.
- Copper, gold, diamond, and netherite universal one-bucket containers.
- Custom 250 mB glass bottle with a fluid-colored overlay.
- BuildCraft-style thin Fluid Pipes with one-bucket buffers and toggle/redstone modes.
- Redstone Extraction Pipe: powered extraction from its back face to its output face.
- High-Pressure Pipe: 1,000 mB/t transfer and a four-bucket safety buffer.
- Meter Pipe: reports mB/t and emits comparator strength for measured flow.
- Overflow Valve: transfers only while its input storage is at least 75% full.
- Pulse Valve: moves exactly 250 mB on each rising redstone edge.
- Priority Junction: sends fluid toward its placed facing before other outputs.
- Fluid Diode: one-way back-to-front transfer.
- Filter Pipe: copies a filter from any filled API container; sneak-use clears it.
- Mixing Junction: four-bucket same-fluid manifold and foundation for recipe-driven mixing.
- Universal Fluid Splash Potion: 250 mB throwable container that places a five-block flowing splash.
- Universal Fluid Lingering Potion: 250 mB throwable container whose flowing liquid lasts 10 seconds.

## Pipe controls

- Use a pipe with an empty hand to enable or disable it.
- Sneak-use ordinary pipes to cycle always/high-signal/low-signal modes.
- Place directional pipes against the face they should output toward.
- Use a filled fluid container on a Filter Pipe to select that fluid.
- Sneak-use a Filter Pipe with an empty hand to clear its filter.
- Use a Meter Pipe to read its rolling 20-tick flow rate.

## Build (only when explicitly requested)

Place `fabric-fluid-api-1.3.0.jar` in `libs/`, then run:

```bash
./gradlew build
```

For a fast source check that deliberately does not produce release JARs:

```bash
./gradlew fastCompile
```

The repository workflow builds the independent API first. With GitHub CLI:

```bash
gh workflow run build.yml -f export_jars=false
gh run watch
```

Release JARs are opt-in: run `gh workflow run build.yml -f export_jars=true`
only when an export is wanted.
