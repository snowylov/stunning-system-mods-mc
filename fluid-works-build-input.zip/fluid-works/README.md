# Fluid Works

Fluid Works is a Fabric 1.21.11 industrial fluid-storage mod. It requires the
independent **Fabric Fluid API Easy Containers 1.3.0** mod at compile time and
runtime. The dependency is not embedded or shaded into Fluid Works.

## Content

- Tank: 16 buckets, full-cube industrial tank.
- Reservoir Tank: 12 mB, 14-pixel-wide retained portable tank.
- Fuel Cell: 500 mB portable API container with a fluid-tinted overlay.
- Double Smelted Glass and Reservoir Window.
- Copper, iron, gold, and netherite reservoir casings, controllers, and valves.
- Hollow 3×3×3 through 11×11×11 multiblock reservoirs.
- Observation Window and persistent Fluid Label attachments.
- Bucket and Bottle Dispensers with four-bucket internal buffers.
- Copper, gold, diamond, and netherite universal one-bucket containers.
- Custom 250 mB glass bottle with a fluid-colored overlay.
- Buffered Fluid Pipe and configurable Redstone Fluid Valve foundations.

## Build

Place `fabric-fluid-api-1.3.0.jar` in `libs/`, then run:

```bash
./gradlew build
```

For a fast source check that deliberately does not produce release JARs:

```bash
./gradlew fastCompile
```

The repository workflow builds the independent API first. With GitHub CLI:

```bash
gh workflow run build.yml -f export_jars=false
gh run watch
```

Release JARs are opt-in: run `gh workflow run build.yml -f export_jars=true`
only when an export is wanted.
