package dev.liquidfabric.api.unofficial.client;

import dev.liquidfabric.api.unofficial.core.LiquidRegistry;
import dev.liquidfabric.api.unofficial.core.ModComponents;
import dev.liquidfabric.api.unofficial.core.StoredFluidComponent;
import dev.liquidfabric.api.unofficial.api.container.CustomFluidContainerItemRegistry;
import dev.liquidfabric.api.unofficial.core.FluidOverlayItem;
import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.minecraft.registry.Registries;
import net.minecraft.item.Item;

import java.util.LinkedHashSet;
import java.util.Set;
import dev.liquidfabric.api.unofficial.api.color.FluidColorRegistry;

public final class UtilityItemColorProviders {
    private UtilityItemColorProviders() {}

    public static void register() {
        Set<Item> overlayItems = new LinkedHashSet<>();
        Registries.ITEM.forEach(item -> {
            if (item instanceof FluidOverlayItem) overlayItems.add(item);
        });
        CustomFluidContainerItemRegistry.values().forEach(entry -> overlayItems.add(entry.item()));

        for (Item item : overlayItems) {
            int overlayTintIndex = CustomFluidContainerItemRegistry.find(item)
                    .map(entry -> entry.definition().fluidOverlayTintIndex())
                    .orElse(1);
            registerOverlayItem(item, overlayTintIndex);
        }
    }

    public static void registerOverlayItem(Item item, int overlayTintIndex) {
        ColorProviderRegistry.ITEM.register((stack, tintIndex) -> {
            if (tintIndex != overlayTintIndex) return -1;
            StoredFluidComponent stored = stack.getOrDefault(ModComponents.STORED_FLUID, StoredFluidComponent.EMPTY);
            if (stored.isEmpty()) return 0xFFFFFFFF;
            return 0xFF000000 | FluidColorRegistry.resolve(stored.liquidId(), 0xFFFFFF);
        }, item);
    }
}
