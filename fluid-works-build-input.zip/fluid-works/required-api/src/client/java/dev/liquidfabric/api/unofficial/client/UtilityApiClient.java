package dev.liquidfabric.api.unofficial.client;

import net.fabricmc.api.ClientModInitializer;

public final class UtilityApiClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        UtilityItemColorProviders.register();
    }
}
