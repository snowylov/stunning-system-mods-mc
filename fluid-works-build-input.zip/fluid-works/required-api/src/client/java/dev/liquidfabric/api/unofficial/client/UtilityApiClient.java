package dev.liquidfabric.api.unofficial.client;

import dev.liquidfabric.api.unofficial.UtilityApiMod;
import dev.liquidfabric.api.unofficial.core.fluid.ModUtilityFluids;
import dev.liquidfabric.api.unofficial.needle.ModNeedles;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandlerRegistry;
import net.fabricmc.fabric.api.client.render.fluid.v1.SimpleFluidRenderHandler;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.RenderLayer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.minecraft.util.Identifier;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.minecraft.resource.ResourceType;

public final class UtilityApiClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModNeedles.NEEDLE_PROJECTILE, EmptyNeedleProjectileRenderer::new);
        SourceTaggedFluidTooltip.registerClient();
        UtilityItemColorProviders.register();
        ResourceManagerHelper.get(ResourceType.CLIENT_RESOURCES).registerReloadListener(new FluidClientDefinitionReloadListener());

        UtilityFluidRenderRegistry.register(
                ModUtilityFluids.MILK,
                ModUtilityFluids.FLOWING_MILK,
                Identifier.ofVanilla("block/water_still"),
                Identifier.ofVanilla("block/water_flow"),
                0xFFFFFF
        );

    }
}
