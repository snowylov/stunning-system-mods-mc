package dev.liquidfabric.api.unofficial.core;

import dev.liquidfabric.api.unofficial.liquid.BaseLiquidContainerItem;
import dev.liquidfabric.api.unofficial.liquid.ModLiquidContainers;
import dev.liquidfabric.api.unofficial.needle.NeedleEffectHandler;
import dev.liquidfabric.api.unofficial.needle.NeedleEffectRegistry;
import dev.liquidfabric.api.unofficial.tank.drum.DrumMode;
import dev.liquidfabric.api.unofficial.bucket.BucketEntityCaptureRegistry;
import dev.liquidfabric.api.unofficial.bucket.BlockMaterialBucketRegistry;
import dev.liquidfabric.api.unofficial.api.container.CustomFluidContainerItemRegistry;
import dev.liquidfabric.api.unofficial.api.container.EasyBucketMaterial;
import dev.liquidfabric.api.unofficial.api.container.FluidContainerDefinition;
import dev.liquidfabric.api.unofficial.core.bucket.EasyBucketItem;
import dev.liquidfabric.api.unofficial.helper.item.FluidItemRegistrationHelper;
import dev.liquidfabric.api.unofficial.liquid.EasyBottleItem;
import dev.liquidfabric.api.unofficial.api.bucket.UniversalBucketRegistry;
import dev.liquidfabric.api.unofficial.api.block.BlockFluidContainerDefinition;
import dev.liquidfabric.api.unofficial.api.block.BlockFluidContainerRegistry;
import dev.liquidfabric.api.unofficial.api.block.FluidloggingRegistry;
import dev.liquidfabric.api.unofficial.api.block.JsonFluidloggableBlock;
import dev.liquidfabric.api.unofficial.api.stew.StewFluidBindingRegistry;
import net.minecraft.block.AbstractBlock;
import net.minecraft.item.BlockItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.fluid.Fluid;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.util.math.Direction;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidStorage;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import org.jetbrains.annotations.Nullable;
import java.util.function.BiFunction;
import net.minecraft.item.Item;
import net.minecraft.util.Identifier;
import net.minecraft.registry.tag.TagKey;
import java.util.function.Predicate;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;

/**
 * Public addon-facing registration surface.
 *
 * This class intentionally avoids auto-registering vanilla objects after registry freeze.
 * Addon mods should call these helpers during their own initialization before gameplay starts.
 */
public final class UtilityApiRegistries {
    private static final Map<Identifier, Supplier<Block>> TANK_TYPE_FACTORIES = new LinkedHashMap<>();
    private static final Map<Identifier, Supplier<Block>> PIPE_TYPE_FACTORIES = new LinkedHashMap<>();
    private static final Map<Identifier, DrumSpec> DRUM_TYPES = new LinkedHashMap<>();

    private UtilityApiRegistries() {}

    public static void registerLiquidType(Identifier id, int color, boolean drinkable, boolean potionLike) {
        LiquidRegistry.register(id, color, drinkable, potionLike);
    }

    public static void registerLiquidType(Identifier id, int color, boolean drinkable, boolean potionLike, boolean canBeNeedled) {
        LiquidRegistry.register(id, color, drinkable, potionLike, canBeNeedled);
    }

    public static <T extends Entity> void registerBucketEntityCapture(EntityType<T> type, Item bucketItem, Predicate<T> predicate) {
        BucketEntityCaptureRegistry.register(type, bucketItem, predicate);
    }

    public static <T extends Entity> void registerBucketEntityCapture(Identifier id, EntityType<T> type, Item bucketItem, Predicate<T> predicate, int priority) {
        BucketEntityCaptureRegistry.register(id, type, bucketItem, predicate, priority);
    }

    public static boolean unregisterBucketEntityCapture(Identifier id) {
        return BucketEntityCaptureRegistry.unregister(id);
    }

    public static void registerBlockMaterialBucket(TagKey<Block> pickupTag, Item bucketItem, Block placementBlock) {
        BlockMaterialBucketRegistry.register(pickupTag, bucketItem, placementBlock);
    }

    public static void registerBlockMaterialBucket(Identifier id, TagKey<Block> pickupTag, Item bucketItem, Block placementBlock, int priority) {
        BlockMaterialBucketRegistry.register(id, pickupTag, bucketItem, placementBlock, priority);
    }

    public static boolean unregisterBlockMaterialBucket(Identifier id) {
        return BlockMaterialBucketRegistry.unregister(id);
    }

    /** Registers a placeable, component-backed bucket whose layer1 is fluid-tinted. */
    public static EasyBucketItem registerEasyBucket(Identifier itemId, EasyBucketMaterial material, Item.Settings settings) {
        EasyBucketItem item = FluidItemRegistrationHelper.register(itemId, new EasyBucketItem(settings.maxCount(1), material));
        CustomFluidContainerItemRegistry.register(itemId, item, FluidContainerDefinition.bucket(material.capacityDroplets()));
        return item;
    }

    /** Registers a drinkable overlay bottle with conventional potion behavior. */
    public static EasyBottleItem registerEasyBottle(Identifier itemId, Item.Settings settings, long capacityDroplets,
                                                    boolean potionLiquidsAllowed, int sips, boolean returnsGlassBottle) {
        EasyBottleItem item = FluidItemRegistrationHelper.register(itemId,
                new EasyBottleItem(settings, capacityDroplets, potionLiquidsAllowed, true, sips, returnsGlassBottle));
        CustomFluidContainerItemRegistry.register(itemId, item,
                FluidContainerDefinition.bottle(capacityDroplets, potionLiquidsAllowed));
        return item;
    }

    /** Hooks an already-registered item into UtilityAPI's stored-fluid component and overlay tinting. */
    public static void registerCustomFluidContainerItem(Identifier hookId, Item item, FluidContainerDefinition definition) {
        CustomFluidContainerItemRegistry.register(hookId, item, definition);
    }

    public static boolean unregisterCustomFluidContainerItem(Identifier hookId) {
        return CustomFluidContainerItemRegistry.unregister(hookId);
    }

    /** Registers a bowl family for cooking, storage, recipe-viewer, and automation compatibility. */
    public static void registerStewFluidBinding(Identifier hookId, Item bowl, Item mushroomStew,
                                                Item suspiciousStew) {
        StewFluidBindingRegistry.register(hookId, bowl, mushroomStew, suspiciousStew,
                Registries.ITEM.getId(mushroomStew), Registries.ITEM.getId(suspiciousStew),
                FluidContainerSizes.BOWL_DROPLETS, null, false, 0);
    }

    /** Registers a fully customized bowl family, optionally with one reusable overlay bowl item. */
    public static void registerStewFluidBinding(Identifier hookId, Item bowl, Item mushroomStew,
                                                Item suspiciousStew, Identifier mushroomLiquid,
                                                Identifier suspiciousLiquid, long amountDroplets,
                                                Item universalOverlayBowl,
                                                boolean automaticSuspiciousTransfer, int priority) {
        StewFluidBindingRegistry.register(hookId, bowl, mushroomStew, suspiciousStew,
                mushroomLiquid, suspiciousLiquid, amountDroplets, universalOverlayBowl,
                automaticSuspiciousTransfer, priority);
    }

    public static boolean unregisterStewFluidBinding(Identifier hookId) {
        return StewFluidBindingRegistry.unregister(hookId);
    }

    public static void registerUniversalBucket(Identifier hookId, Identifier fluidId, Item bucketItem, int priority) {
        UniversalBucketRegistry.register(hookId, fluidId, bucketItem, priority);
    }

    public static boolean unregisterUniversalBucket(Identifier hookId) {
        return UniversalBucketRegistry.unregister(hookId);
    }

    public static void registerFluidContainerBlock(Identifier hookId, Block block,
                                                   BlockFluidContainerDefinition definition) {
        BlockFluidContainerRegistry.register(hookId, block, definition);
    }

    public static void registerFluidContainerBlock(Identifier hookId, Block block,
                                                   BlockFluidContainerDefinition definition,
                                                   BlockFluidContainerRegistry.StorageProvider provider) {
        BlockFluidContainerRegistry.register(hookId, block, definition, provider);
    }

    public static boolean unregisterFluidContainerBlock(Identifier hookId) {
        return BlockFluidContainerRegistry.unregister(hookId);
    }

    /** Exposes a block entity through Fabric Transfer API without mixins. */
    public static <T extends BlockEntity> void registerFluidStorage(BlockEntityType<T> type,
            BiFunction<T, @Nullable Direction, @Nullable Storage<FluidVariant>> provider) {
        FluidStorage.SIDED.registerForBlockEntity(provider::apply, type);
    }

    public static void registerFluidlogging(Identifier hookId, Block block, Fluid fluid, String booleanPropertyName) {
        FluidloggingRegistry.register(hookId, block, fluid, booleanPropertyName);
    }

    public static boolean unregisterFluidlogging(Identifier hookId) {
        return FluidloggingRegistry.unregister(hookId);
    }

    /** Registers a JSON-configurable fluidloggable block and its block item. */
    public static JsonFluidloggableBlock registerJsonFluidloggableBlock(Identifier blockId,
            AbstractBlock.Settings blockSettings, Item.Settings itemSettings) {
        JsonFluidloggableBlock block = Registry.register(Registries.BLOCK, blockId,
                new JsonFluidloggableBlock(blockSettings));
        Registry.register(Registries.ITEM, blockId, new BlockItem(block, itemSettings));
        return block;
    }

    /** Registers any already-constructed block plus its normal block item. */
    public static <T extends Block> T registerBlockWithItem(Identifier blockId, T block, Item.Settings itemSettings) {
        T registered = Registry.register(Registries.BLOCK, blockId, block);
        Registry.register(Registries.ITEM, blockId, new BlockItem(registered, itemSettings));
        return registered;
    }

    public static void registerNeedleEffect(NeedleEffectHandler handler) {
        NeedleEffectRegistry.register(handler);
    }

    public static void registerContainerAlias(Identifier id, BaseLiquidContainerItem item) {
        ModLiquidContainers.CONTAINERS_BY_NAME.put(id.toString(), item);
        ModLiquidContainers.CONTAINERS_BY_NAME.put(id.getPath(), item);
    }

    public static void registerTankType(Identifier id, Supplier<Block> factory) {
        TANK_TYPE_FACTORIES.put(id, factory);
    }

    public static void registerPipeType(Identifier id, Supplier<Block> factory) {
        PIPE_TYPE_FACTORIES.put(id, factory);
    }

    public static void registerDrumType(Identifier id, long capacityDroplets, DrumMode mode) {
        DRUM_TYPES.put(id, new DrumSpec(capacityDroplets, mode));
    }

    public static Map<Identifier, Supplier<Block>> tankTypeFactories() {
        return Map.copyOf(TANK_TYPE_FACTORIES);
    }

    public static Map<Identifier, Supplier<Block>> pipeTypeFactories() {
        return Map.copyOf(PIPE_TYPE_FACTORIES);
    }

    public static Map<Identifier, DrumSpec> drumTypes() {
        return Map.copyOf(DRUM_TYPES);
    }

    public record DrumSpec(long capacityDroplets, DrumMode mode) {}
}
