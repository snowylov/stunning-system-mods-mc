package dev.liquidfabric.api.unofficial;

import dev.liquidfabric.api.unofficial.core.ModComponents;
import dev.liquidfabric.api.unofficial.core.LiquidFabricConfig;
import dev.liquidfabric.api.unofficial.core.ModStatusEffects;
import dev.liquidfabric.api.unofficial.core.fluid.ModUtilityFluids;
import dev.liquidfabric.api.unofficial.core.bucket.ModUniversalBuckets;
import dev.liquidfabric.api.unofficial.liquid.ModLiquidContainers;
import dev.liquidfabric.api.unofficial.needle.ModNeedles;
import dev.liquidfabric.api.unofficial.tank.ModTanksAndPipes;
import dev.liquidfabric.api.unofficial.tech.ModTechStuff;
import dev.liquidfabric.api.unofficial.command.UtilityApiCommands;
import dev.liquidfabric.api.unofficial.core.UtilityApiCommonEvents;
import dev.liquidfabric.api.unofficial.needle.station.NeedleFillingStation;
import dev.liquidfabric.api.unofficial.slime.SlimeBucketHooks;
import dev.liquidfabric.api.unofficial.worldgen.ModWorldgen;
import net.fabricmc.api.ModInitializer;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class UtilityApiMod implements ModInitializer {
    public static final String MOD_ID = "liquid-fabric-api-unofficial-fabric-api";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        LiquidFabricConfig.load();
        ModComponents.register();
        ModStatusEffects.register();
        ModUtilityFluids.register();
        ModUniversalBuckets.register();
        dev.liquidfabric.api.unofficial.core.LiquidRegistry.bootstrapDefaults();
        ModLiquidContainers.register();
        ModNeedles.register();
        ModTanksAndPipes.register();
        ModTechStuff.register();
        UtilityApiCommands.register();
        UtilityApiCommonEvents.register();
        NeedleFillingStation.register();
        SlimeBucketHooks.register();
        ModWorldgen.register();
    }
}
