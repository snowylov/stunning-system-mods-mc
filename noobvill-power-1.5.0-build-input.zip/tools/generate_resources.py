#!/usr/bin/env python3
"""Generate the repetitive recipes, models, translations, and common tags."""

from __future__ import annotations

import json
import shutil
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RESOURCES = ROOT / "src/main/resources"
NAMESPACE = "noobvill_power"

BLOCKS_WITH_ITEMS = [
    "compressed_coal",
    "super_compressed_coal",
    "ultra_compressed_coal",
    "redstone_heart",
    "force_field_projector",
    "emp",
    "rose_lamp",
    "love_lamp",
    "moon",
    "healing_lamp",
    "sun_lantern",
]
BLOCKS = [*BLOCKS_WITH_ITEMS, "force_field"]
ITEMS = [
    *BLOCKS_WITH_ITEMS,
    "industrial_diamond",
    "industrial_diamond_dust",
    "diamond_dust",
    "power_crystal",
    "power_crystal_dust",
    "industrial_power_crystal",
    "industrial_power_crystal_dust",
    "cube_module",
    "sphere_module",
    "cylinder_module",
    "tube_module",
    "scale_module",
    "offset_x_module",
    "offset_y_module",
    "offset_z_module",
]

ITEM_TEXTURES = {
    "industrial_diamond": "industrial_diamond",
    "industrial_diamond_dust": "industrial_diamond_dust",
    "diamond_dust": "diamond_dust",
    "power_crystal": "power_crystal",
    "power_crystal_dust": "power_crystal_dust",
    "industrial_power_crystal": "industrial_power_crystal",
    "industrial_power_crystal_dust": "industrial_power_crystal_dust",
    "cube_module": "minecraft:item/iron_ingot",
    "sphere_module": "minecraft:item/slime_ball",
    "cylinder_module": "minecraft:item/blaze_rod",
    "tube_module": "minecraft:item/ender_pearl",
    "scale_module": "minecraft:item/repeater",
    "offset_x_module": "minecraft:item/redstone_torch",
    "offset_y_module": "minecraft:item/redstone_torch",
    "offset_z_module": "minecraft:item/redstone_torch",
}

NAMES = {
    "compressed_coal": "Compressed Coal Block",
    "super_compressed_coal": "Super Compressed Coal Block",
    "ultra_compressed_coal": "Ultra Compressed Coal Block",
    "redstone_heart": "Redstone Heart",
    "force_field_projector": "Force Field Projector",
    "force_field": "Force Field",
    "emp": "EMP",
    "rose_lamp": "Rose Lamp",
    "love_lamp": "Love Lamp",
    "moon": "Moon",
    "healing_lamp": "Healing Lamp",
    "sun_lantern": "Sun Lantern",
    "industrial_diamond": "Industrial Diamond",
    "industrial_diamond_dust": "Industrial Diamond Dust",
    "diamond_dust": "Diamond Dust",
    "power_crystal": "Power Crystal",
    "power_crystal_dust": "Power Crystal Dust",
    "industrial_power_crystal": "Industrial Power Crystal",
    "industrial_power_crystal_dust": "Industrial Power Crystal Dust",
    "cube_module": "Cube Force Field Module",
    "sphere_module": "Sphere Force Field Module",
    "cylinder_module": "Cylinder Force Field Module",
    "tube_module": "Tube Force Field Module",
    "scale_module": "Scale Module",
    "offset_x_module": "X Offset Module",
    "offset_y_module": "Y Offset Module",
    "offset_z_module": "Z Offset Module",
}


def write_json(relative: str, value: object) -> None:
    path = RESOURCES / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def shaped(pattern: list[str], key: dict[str, str], result: str, count: int = 1) -> dict:
    return {
        "type": "minecraft:crafting_shaped",
        "category": "misc",
        "pattern": pattern,
        "key": {symbol: ingredient for symbol, ingredient in key.items()},
        "result": {"id": result, "count": count},
    }


def shapeless(ingredients: list[str], result: str, count: int = 1) -> dict:
    return {
        "type": "minecraft:crafting_shapeless",
        "category": "misc",
        "ingredients": ingredients,
        "result": {"id": result, "count": count},
    }


def generate_models() -> None:
    coal_parent = "minecraft:block/coal_block"
    for block in ("compressed_coal", "super_compressed_coal", "ultra_compressed_coal"):
        write_json(f"assets/{NAMESPACE}/models/block/{block}.json", {"parent": coal_parent})
    write_json(
        f"assets/{NAMESPACE}/models/block/redstone_heart.json",
        {"parent": "minecraft:block/cube_all", "textures": {"all": f"{NAMESPACE}:block/redstone_heart"}},
    )
    write_json(
        f"assets/{NAMESPACE}/models/block/force_field_projector.json",
        {"parent": "minecraft:block/cube_all", "textures": {"all": "minecraft:block/iron_block"}},
    )
    write_json(
        f"assets/{NAMESPACE}/models/block/force_field.json",
        {
            "parent": "minecraft:block/cube_all",
            "render_type": "minecraft:translucent",
            "textures": {"all": "minecraft:misc/forcefield"},
        },
    )
    write_json(
        f"assets/{NAMESPACE}/models/block/emp.json",
        {
            "parent": "minecraft:block/cube_bottom_top",
            "textures": {
                "top": "minecraft:block/tnt_top",
                "bottom": "minecraft:block/tnt_bottom",
                "side": "minecraft:block/tnt_side",
            },
        },
    )
    lamps = ("rose_lamp", "love_lamp", "moon", "healing_lamp", "sun_lantern")
    for lamp in lamps:
        write_json(
            f"assets/{NAMESPACE}/models/block/{lamp}.json",
            {"parent": "minecraft:block/cube_all", "textures": {"all": f"{NAMESPACE}:block/{lamp}"}},
        )

    for block in BLOCKS:
        if block in ("force_field_projector", "emp") or block in lamps:
            write_json(
                f"assets/{NAMESPACE}/blockstates/{block}.json",
                {"multipart": [{"apply": {"model": f"{NAMESPACE}:block/{block}"}}]},
            )
        else:
            write_json(
                f"assets/{NAMESPACE}/blockstates/{block}.json",
                {"variants": {"": {"model": f"{NAMESPACE}:block/{block}"}}},
            )

    for block in BLOCKS_WITH_ITEMS:
        write_json(
            f"assets/{NAMESPACE}/models/item/{block}.json",
            {"parent": f"{NAMESPACE}:block/{block}"},
        )
        write_json(
            f"assets/{NAMESPACE}/items/{block}.json",
            {"model": {"type": "minecraft:model", "model": f"{NAMESPACE}:item/{block}"}},
        )

    for item, texture in ITEM_TEXTURES.items():
        texture_id = texture if ":" in texture else f"{NAMESPACE}:item/{texture}"
        write_json(
            f"assets/{NAMESPACE}/models/item/{item}.json",
            {"parent": "minecraft:item/generated", "textures": {"layer0": texture_id}},
        )
        write_json(
            f"assets/{NAMESPACE}/items/{item}.json",
            {"model": {"type": "minecraft:model", "model": f"{NAMESPACE}:item/{item}"}},
        )


def generate_recipes() -> None:
    compression = [
        ("minecraft:coal_block", "compressed_coal"),
        (f"{NAMESPACE}:compressed_coal", "super_compressed_coal"),
        (f"{NAMESPACE}:super_compressed_coal", "ultra_compressed_coal"),
        (f"{NAMESPACE}:ultra_compressed_coal", "industrial_diamond"),
    ]
    for ingredient, output in compression:
        write_json(
            f"data/{NAMESPACE}/recipe/{output}.json",
            shaped(["###", "###", "###"], {"#": ingredient}, f"{NAMESPACE}:{output}"),
        )

    decompression = [
        ("compressed_coal", "minecraft:coal_block"),
        ("super_compressed_coal", f"{NAMESPACE}:compressed_coal"),
        ("ultra_compressed_coal", f"{NAMESPACE}:super_compressed_coal"),
    ]
    for source, output in decompression:
        write_json(
            f"data/{NAMESPACE}/recipe/{source}_unpacking.json",
            shapeless([f"{NAMESPACE}:{source}"], output, 9),
        )

    dust_pairs = [
        ("diamond_dust", "minecraft:diamond"),
        ("industrial_diamond_dust", f"{NAMESPACE}:industrial_diamond"),
        ("power_crystal_dust", f"{NAMESPACE}:power_crystal"),
        ("industrial_power_crystal_dust", f"{NAMESPACE}:industrial_power_crystal"),
    ]
    for dust, whole in dust_pairs:
        write_json(
            f"data/{NAMESPACE}/recipe/{whole.split(':')[-1]}_from_dust.json",
            shaped(["###", "###", "###"], {"#": f"{NAMESPACE}:{dust}"}, whole),
        )
        write_json(
            f"data/{NAMESPACE}/recipe/{dust}.json",
            shapeless([whole], f"{NAMESPACE}:{dust}", 9),
        )

    write_json(
        f"data/{NAMESPACE}/recipe/power_crystal.json",
        shaped(["RRR", "RDR", "RRR"], {"R": "minecraft:redstone", "D": "minecraft:diamond"},
               f"{NAMESPACE}:power_crystal"),
    )
    write_json(
        f"data/{NAMESPACE}/recipe/industrial_power_crystal.json",
        shaped(["RRR", "RDR", "RRR"],
               {"R": "minecraft:redstone", "D": f"{NAMESPACE}:industrial_diamond"},
               f"{NAMESPACE}:industrial_power_crystal"),
    )
    write_json(
        f"data/{NAMESPACE}/recipe/redstone_heart.json",
        shaped(["###", "###", "###"], {"#": f"{NAMESPACE}:power_crystal"},
               f"{NAMESPACE}:redstone_heart"),
    )
    write_json(
        f"data/{NAMESPACE}/recipe/redstone_heart_unpacking.json",
        shapeless([f"{NAMESPACE}:redstone_heart"], f"{NAMESPACE}:power_crystal", 9),
    )
    write_json(
        f"data/{NAMESPACE}/recipe/force_field_projector.json",
        shaped(["IPI", "RHR", "IRI"],
               {"I": "minecraft:iron_ingot", "P": f"{NAMESPACE}:power_crystal",
                "R": "minecraft:redstone", "H": f"{NAMESPACE}:redstone_heart"},
               f"{NAMESPACE}:force_field_projector"),
    )
    write_json(
        f"data/{NAMESPACE}/recipe/emp.json",
        shaped(["IRI", "RTR", "IRI"],
               {"I": "minecraft:iron_ingot", "R": "minecraft:redstone", "T": "minecraft:tnt"},
               f"{NAMESPACE}:emp"),
    )

    lamp_recipes = {
        "rose_lamp": "#c:ingots/rose_gold",
        "love_lamp": "minecraft:pink_wool",
        "moon": "minecraft:amethyst_shard",
        "healing_lamp": "minecraft:glistering_melon_slice",
        "sun_lantern": "minecraft:gold_ingot",
    }
    for lamp, surround in lamp_recipes.items():
        write_json(
            f"data/{NAMESPACE}/recipe/{lamp}.json",
            shaped(["###", "#H#", "###"], {"#": surround, "H": f"{NAMESPACE}:redstone_heart"},
                   f"{NAMESPACE}:{lamp}"),
        )

    module_recipes = {
        "cube_module": "minecraft:iron_block",
        "sphere_module": "minecraft:slime_ball",
        "cylinder_module": "minecraft:blaze_rod",
        "tube_module": "minecraft:ender_pearl",
        "scale_module": "minecraft:repeater",
        "offset_x_module": "minecraft:redstone_torch",
        "offset_y_module": "minecraft:torch",
        "offset_z_module": "minecraft:soul_torch",
    }
    for module, center in module_recipes.items():
        write_json(
            f"data/{NAMESPACE}/recipe/{module}.json",
            shaped([" R ", "RCR", " R "], {"R": "minecraft:redstone", "C": center},
                   f"{NAMESPACE}:{module}"),
        )

    tool_armor = {
        "diamond_sword": ([" D ", " D ", " S "], {"D": f"{NAMESPACE}:industrial_diamond", "S": "minecraft:stick"}),
        "diamond_shovel": ([" D ", " S ", " S "], {"D": f"{NAMESPACE}:industrial_diamond", "S": "minecraft:stick"}),
        "diamond_pickaxe": (["DDD", " S ", " S "], {"D": f"{NAMESPACE}:industrial_diamond", "S": "minecraft:stick"}),
        "diamond_axe": (["DD ", "DS ", " S "], {"D": f"{NAMESPACE}:industrial_diamond", "S": "minecraft:stick"}),
        "diamond_hoe": (["DD ", " S ", " S "], {"D": f"{NAMESPACE}:industrial_diamond", "S": "minecraft:stick"}),
        "diamond_helmet": (["DDD", "D D"], {"D": f"{NAMESPACE}:industrial_diamond"}),
        "diamond_chestplate": (["D D", "DDD", "DDD"], {"D": f"{NAMESPACE}:industrial_diamond"}),
        "diamond_leggings": (["DDD", "D D", "D D"], {"D": f"{NAMESPACE}:industrial_diamond"}),
        "diamond_boots": (["D D", "D D"], {"D": f"{NAMESPACE}:industrial_diamond"}),
    }
    for result, (pattern, key) in tool_armor.items():
        write_json(
            f"data/{NAMESPACE}/recipe/industrial_{result}.json",
            shaped(pattern, key, f"minecraft:{result}"),
        )


def generate_tags_and_loot() -> None:
    for block in BLOCKS:
        write_json(f"data/c/tags/block/{block}.json", {"replace": False, "values": [f"{NAMESPACE}:{block}"]})
        write_json(f"data/{NAMESPACE}/tags/block/{block}.json", {"replace": False, "values": [f"{NAMESPACE}:{block}"]})
    for item in ITEMS:
        write_json(f"data/c/tags/item/{item}.json", {"replace": False, "values": [f"{NAMESPACE}:{item}"]})
        write_json(f"data/{NAMESPACE}/tags/item/{item}.json", {"replace": False, "values": [f"{NAMESPACE}:{item}"]})

    write_json("data/c/tags/block/redstone_hearts.json", {"replace": False, "values": [f"{NAMESPACE}:redstone_heart"]})
    write_json("data/c/tags/item/redstone_hearts.json", {"replace": False, "values": [f"{NAMESPACE}:redstone_heart"]})
    write_json("data/c/tags/block/force_field_projectors.json", {"replace": False, "values": [f"{NAMESPACE}:force_field_projector"]})
    write_json("data/c/tags/block/emps.json", {"replace": False, "values": [f"{NAMESPACE}:emp"]})
    write_json("data/c/tags/item/emps.json", {"replace": False, "values": [f"{NAMESPACE}:emp"]})
    lamps = [f"{NAMESPACE}:{lamp}" for lamp in ("rose_lamp", "love_lamp", "moon", "healing_lamp", "sun_lantern")]
    write_json("data/c/tags/block/lamps.json", {"replace": False, "values": lamps})
    write_json("data/c/tags/item/lamps.json", {"replace": False, "values": lamps})
    write_json("data/c/tags/item/power_crystals.json", {"replace": False, "values": [f"{NAMESPACE}:power_crystal", f"{NAMESPACE}:industrial_power_crystal"]})
    write_json("data/c/tags/item/dusts/diamond.json", {"replace": False, "values": [f"{NAMESPACE}:diamond_dust", f"{NAMESPACE}:industrial_diamond_dust"]})
    write_json("data/minecraft/tags/block/mineable/pickaxe.json", {"replace": False, "values": [f"{NAMESPACE}:{block}" for block in BLOCKS_WITH_ITEMS]})

    for block in BLOCKS_WITH_ITEMS:
        write_json(
            f"data/{NAMESPACE}/loot_table/blocks/{block}.json",
            {
                "type": "minecraft:block",
                "pools": [{
                    "rolls": 1,
                    "entries": [{"type": "minecraft:item", "name": f"{NAMESPACE}:{block}"}],
                    "conditions": [{"condition": "minecraft:survives_explosion"}],
                }],
                "random_sequence": f"{NAMESPACE}:blocks/{block}",
            },
        )


def generate_language() -> None:
    language = {}
    for block in BLOCKS:
        language[f"block.{NAMESPACE}.{block}"] = NAMES[block]
    for item in ITEMS:
        if item not in BLOCKS_WITH_ITEMS:
            language[f"item.{NAMESPACE}.{item}"] = NAMES[item]
    language.update({
        "message.noobvill_power.projector_shape": "Force-field shape: %s",
        "message.noobvill_power.projector_radius": "Force-field radius: %s",
        "message.noobvill_power.projector_offset_x": "Force-field X offset: %s",
        "message.noobvill_power.projector_offset_y": "Force-field Y offset: %s",
        "message.noobvill_power.projector_offset_z": "Force-field Z offset: %s",
        "message.noobvill_power.projector_enabled": "Force field enabled",
        "message.noobvill_power.projector_disabled": "Force field disabled",
        "message.noobvill_power.heart_required": "A Redstone Heart must be within 3 blocks",
        "message.noobvill_power.teleport_blocked": "The force field blocks teleportation",
        "tooltip.noobvill_power.emp": "Temporarily breaches force fields for 15 seconds.",
        "message.noobvill_power.lamp_heart_mode": "Lamp mode: Redstone Heart",
        "message.noobvill_power.lamp_redstone_mode": "Lamp mode: Redstone signal",
        "tooltip.noobvill_power.lamp_mode": "Sneak-right-click after placing to toggle Heart/Redstone mode.",
        "tooltip.noobvill_power.rose_lamp": "Light 15 when powered; light 7 otherwise.",
        "tooltip.noobvill_power.love_lamp": "Powered: nearby adult animals enter love mode.",
        "tooltip.noobvill_power.moon": "Full moon or power: light 15 and Redstone signal 15.",
        "tooltip.noobvill_power.healing_lamp": "Powered: heals nearby players, animals, and pets.",
        "tooltip.noobvill_power.sun_lantern": "Light 15 when powered; light 7 otherwise.",
    })
    write_json(f"assets/{NAMESPACE}/lang/en_us.json", language)


def copy_textures() -> None:
    uploads = ROOT.parent / "upload"
    item_textures = RESOURCES / f"assets/{NAMESPACE}/textures/item"
    block_textures = RESOURCES / f"assets/{NAMESPACE}/textures/block"
    item_textures.mkdir(parents=True, exist_ok=True)
    block_textures.mkdir(parents=True, exist_ok=True)
    sources = {
        "Industrial_diamond.PNG": item_textures / "industrial_diamond.png",
        "Industrial_diamond_dust.PNG": item_textures / "industrial_diamond_dust.png",
        "diamond_dust.PNG": item_textures / "diamond_dust.png",
        "Power_crystal.PNG": item_textures / "power_crystal.png",
        "Power_crystal_dust.PNG": item_textures / "power_crystal_dust.png",
        "Industrial_power_crystal.PNG": item_textures / "industrial_power_crystal.png",
        "Industrial_power_crystal_dust.PNG": item_textures / "industrial_power_crystal_dust.png",
        "redstone_block(1).png": block_textures / "redstone_heart.png",
        "IMG_2938.PNG": block_textures / "rose_lamp.png",
        "IMG_2939.PNG": block_textures / "love_lamp.png",
        "IMG_2936.PNG": block_textures / "moon.png",
        "IMG_2937.PNG": block_textures / "healing_lamp.png",
        "IMG_2945.PNG": block_textures / "sun_lantern.png",
    }
    for source, destination in sources.items():
        shutil.copyfile(uploads / source, destination)


def main() -> None:
    generate_models()
    generate_recipes()
    generate_tags_and_loot()
    generate_language()
    copy_textures()


if __name__ == "__main__":
    main()
