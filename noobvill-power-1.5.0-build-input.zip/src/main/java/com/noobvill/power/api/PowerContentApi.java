package com.noobvill.power.api;

import com.noobvill.power.ForceFieldManager;
import com.noobvill.power.NoobvillPower;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * Stable integration surface for Redstone Hearts and EMP charges.
 *
 * <p>Other mods should use these identifiers and common tags instead of
 * referencing the implementation registry class directly.</p>
 */
public final class PowerContentApi {
    public static final Identifier REDSTONE_HEART_ID = NoobvillPower.id("redstone_heart");
    public static final Identifier EMP_ID = NoobvillPower.id("emp");

    public static final TagKey<Block> REDSTONE_HEART_BLOCKS = blockTag("redstone_hearts");
    public static final TagKey<Item> REDSTONE_HEART_ITEMS = itemTag("redstone_hearts");
    public static final TagKey<Block> EMP_BLOCKS = blockTag("emps");
    public static final TagKey<Item> EMP_ITEMS = itemTag("emps");

    public static final int DEFAULT_EMP_RADIUS = 3;
    public static final int DEFAULT_EMP_DURATION_TICKS = 300;

    private PowerContentApi() {
    }

    public static boolean isRedstoneHeart(BlockState state) {
        return state.isIn(REDSTONE_HEART_BLOCKS);
    }

    public static boolean isRedstoneHeart(ItemStack stack) {
        return stack.isIn(REDSTONE_HEART_ITEMS);
    }

    public static boolean isEmp(BlockState state) {
        return state.isIn(EMP_BLOCKS);
    }

    public static boolean isEmp(ItemStack stack) {
        return stack.isIn(EMP_ITEMS);
    }

    /** Returns whether a tagged Redstone Heart exists within the inclusive cube around {@code origin}. */
    public static boolean hasRedstoneHeart(World world, BlockPos origin, int range) {
        if (range < 0) {
            throw new IllegalArgumentException("Redstone Heart search range cannot be negative");
        }
        for (BlockPos candidate : BlockPos.iterate(origin.add(-range, -range, -range),
                origin.add(range, range, range))) {
            if (isRedstoneHeart(world.getBlockState(candidate))) {
                return true;
            }
        }
        return false;
    }

    /** Opens the same three-block, 15-second breach used by the built-in EMP. */
    public static void triggerEmpBreach(ServerWorld world, BlockPos origin) {
        triggerEmpBreach(world, origin, DEFAULT_EMP_RADIUS, DEFAULT_EMP_DURATION_TICKS);
    }

    /**
     * Temporarily removes force-field segments in a spherical radius.
     * Repeated pulses extend affected positions to the newest restoration time.
     */
    public static void triggerEmpBreach(ServerWorld world, BlockPos origin, int radius, int durationTicks) {
        ForceFieldManager.createEmpBreach(world, origin, radius, durationTicks);
    }

    private static TagKey<Block> blockTag(String path) {
        return TagKey.of(RegistryKeys.BLOCK, Identifier.of("c", path));
    }

    private static TagKey<Item> itemTag(String path) {
        return TagKey.of(RegistryKeys.ITEM, Identifier.of("c", path));
    }
}
