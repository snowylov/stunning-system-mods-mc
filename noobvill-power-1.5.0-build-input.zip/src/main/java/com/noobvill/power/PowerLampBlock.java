package com.noobvill.power;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.block.WireOrientation;
import org.jetbrains.annotations.Nullable;

/** A Redstone Heart-powered lamp that can be switched to ordinary Redstone mode. */
public final class PowerLampBlock extends Block {
    public static final BooleanProperty POWERED = BooleanProperty.of("powered");
    public static final BooleanProperty REDSTONE_MODE = BooleanProperty.of("redstone_mode");
    private static final int UPDATE_INTERVAL = 10;

    public enum Effect {
        NONE,
        LOVE,
        HEALING,
        MOON
    }

    private final Effect effect;

    public PowerLampBlock(Settings settings, Effect effect) {
        super(settings);
        this.effect = effect;
        setDefaultState(getStateManager().getDefaultState()
                .with(POWERED, false)
                .with(REDSTONE_MODE, false));
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(POWERED, REDSTONE_MODE);
    }

    @Override
    protected void onBlockAdded(BlockState state, World world, BlockPos pos, BlockState oldState, boolean notify) {
        super.onBlockAdded(state, world, pos, oldState, notify);
        if (!world.isClient()) {
            world.scheduleBlockTick(pos, this, 1);
        }
    }

    @Override
    protected void neighborUpdate(BlockState state, World world, BlockPos pos, Block sourceBlock,
            @Nullable WireOrientation wireOrientation, boolean notify) {
        super.neighborUpdate(state, world, pos, sourceBlock, wireOrientation, notify);
        if (!world.isClient() && state.get(REDSTONE_MODE)) {
            world.scheduleBlockTick(pos, this, 1);
        }
    }

    @Override
    protected void scheduledTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
        boolean powered = isPowered(world, pos, state);
        if (state.get(POWERED) != powered) {
            world.setBlockState(pos, state.with(POWERED, powered), Block.NOTIFY_ALL);
        }

        // Scheduled ticks are ten ticks apart, so this selects one of every two ticks
        // regardless of the game-time phase at which the lamp was placed.
        if (powered && Math.floorMod(world.getTime(), 20L) < UPDATE_INTERVAL) {
            applyEffect(world, pos);
        }
        world.scheduleBlockTick(pos, this, UPDATE_INTERVAL);
    }

    public void refresh(ServerWorld world, BlockPos pos, BlockState state) {
        world.scheduleBlockTick(pos, this, 1);
    }

    private boolean isPowered(ServerWorld world, BlockPos pos, BlockState state) {
        boolean selectedPower = state.get(REDSTONE_MODE)
                ? world.isReceivingRedstonePower(pos)
                : ForceFieldManager.hasHeart(world, pos);
        return selectedPower || effect == Effect.MOON && isFullMoonNight(world);
    }

    private static boolean isFullMoonNight(ServerWorld world) {
        long day = Math.floorDiv(world.getTimeOfDay(), 24_000L);
        return world.isNight() && Math.floorMod(day, 8L) == 0L;
    }

    private void applyEffect(ServerWorld world, BlockPos pos) {
        Box box = Box.of(Vec3d.ofCenter(pos), 16.0, 8.0, 16.0);
        if (effect == Effect.LOVE) {
            world.getEntitiesByClass(AnimalEntity.class, box,
                    animal -> animal.getBreedingAge() == 0 && !animal.isInLove())
                    .forEach(animal -> animal.lovePlayer(null));
        } else if (effect == Effect.HEALING) {
            world.getEntitiesByClass(PlayerEntity.class, box, player -> player.isAlive())
                    .forEach(player -> player.heal(1.0F));
            world.getEntitiesByClass(AnimalEntity.class, box, animal -> animal.isAlive())
                    .forEach(animal -> animal.heal(1.0F));
        }
    }

    @Override
    protected boolean emitsRedstonePower(BlockState state) {
        return effect == Effect.MOON;
    }

    @Override
    protected int getWeakRedstonePower(BlockState state, BlockView world, BlockPos pos, Direction direction) {
        return effect == Effect.MOON && state.get(POWERED) ? 15 : 0;
    }
}
