package com.noobvill.power;

import java.util.function.Consumer;

import net.minecraft.component.type.TooltipDisplayComponent;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public final class HazmatArmorItem extends Item {
    public HazmatArmorItem(Settings settings) {
        super(settings);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void appendTooltip(ItemStack stack, TooltipContext context, TooltipDisplayComponent displayComponent,
            Consumer<Text> tooltip, TooltipType type) {
        tooltip.accept(Text.translatable("tooltip.noobvill_power.hazmat_suit").formatted(Formatting.GRAY));
    }
}
