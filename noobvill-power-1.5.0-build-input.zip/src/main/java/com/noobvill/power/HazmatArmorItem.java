package com.noobvill.power;

import java.util.function.Consumer;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public final class HazmatArmorItem extends Item {
    public HazmatArmorItem(Settings settings) {
        super(settings);
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, TooltipType type, Consumer<Text> tooltip) {
        tooltip.accept(Text.translatable("tooltip.noobvill_power.hazmat_suit").formatted(Formatting.GRAY));
    }
}
