package com.noobvill.power;

import java.util.Map;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.block.BlockState;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class NoobvillPower implements ModInitializer {
    public static final String MOD_ID = "noobvill_power";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static final Map<Item, ForceFieldShape> SHAPE_MODULES = Map.of(
            ModContent.CUBE_MODULE, ForceFieldShape.CUBE,
            ModContent.SPHERE_MODULE, ForceFieldShape.SPHERE,
            ModContent.CYLINDER_MODULE, ForceFieldShape.CYLINDER,
            ModContent.TUBE_MODULE, ForceFieldShape.TUBE);

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModAttributes.initialize();
        ModContent.initialize();
        registerBlockControls();
        registerProtection();
        ServerTickEvents.END_WORLD_TICK.register(ForceFieldManager::tick);
        LOGGER.info("Noobvill Power & Forcefields initialized");
    }

    private static void registerBlockControls() {
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            BlockPos pos = hit.getBlockPos();
            BlockState state = world.getBlockState(pos);
            if (state.getBlock() instanceof PowerLampBlock lamp && player.isSneaking()) {
                if (world.isClient()) {
                    return ActionResult.SUCCESS;
                }
                boolean redstoneMode = !state.get(PowerLampBlock.REDSTONE_MODE);
                BlockState changed = state.with(PowerLampBlock.REDSTONE_MODE, redstoneMode);
                world.setBlockState(pos, changed, 3);
                lamp.refresh((ServerWorld) world, pos, changed);
                player.sendMessage(Text.translatable(redstoneMode
                        ? "message.noobvill_power.lamp_redstone_mode"
                        : "message.noobvill_power.lamp_heart_mode"), true);
                return ActionResult.SUCCESS;
            }
            if (!state.isOf(ModContent.FORCE_FIELD_PROJECTOR)) {
                return ActionResult.PASS;
            }
            if (world.isClient()) {
                return ActionResult.SUCCESS;
            }

            ItemStack stack = player.getStackInHand(hand);
            BlockState changed = state;
            Text message;
            ForceFieldShape shape = SHAPE_MODULES.get(stack.getItem());
            if (shape != null) {
                changed = state.with(ForceFieldProjectorBlock.SHAPE, shape);
                message = Text.translatable("message.noobvill_power.projector_shape", shape.asString());
            } else if (stack.isOf(ModContent.SCALE_MODULE)) {
                int current = state.get(ForceFieldProjectorBlock.RADIUS);
                int next = player.isSneaking() ? Math.max(2, current - 1) : Math.min(8, current + 1);
                changed = state.with(ForceFieldProjectorBlock.RADIUS, next);
                message = Text.translatable("message.noobvill_power.projector_radius", next);
            } else if (stack.isOf(ModContent.OFFSET_X_MODULE)) {
                changed = adjustOffset(state, ForceFieldProjectorBlock.OFFSET_X, player.isSneaking());
                message = Text.translatable("message.noobvill_power.projector_offset_x",
                        changed.get(ForceFieldProjectorBlock.OFFSET_X));
            } else if (stack.isOf(ModContent.OFFSET_Y_MODULE)) {
                changed = adjustOffset(state, ForceFieldProjectorBlock.OFFSET_Y, player.isSneaking());
                message = Text.translatable("message.noobvill_power.projector_offset_y",
                        changed.get(ForceFieldProjectorBlock.OFFSET_Y));
            } else if (stack.isOf(ModContent.OFFSET_Z_MODULE)) {
                changed = adjustOffset(state, ForceFieldProjectorBlock.OFFSET_Z, player.isSneaking());
                message = Text.translatable("message.noobvill_power.projector_offset_z",
                        changed.get(ForceFieldProjectorBlock.OFFSET_Z));
            } else if (stack.isEmpty()) {
                boolean activate = !state.get(ForceFieldProjectorBlock.ACTIVE);
                if (activate && !ForceFieldManager.hasHeart((ServerWorld) world, pos)) {
                    player.sendMessage(Text.translatable("message.noobvill_power.heart_required"), true);
                    return ActionResult.FAIL;
                }
                changed = state.with(ForceFieldProjectorBlock.ACTIVE, activate);
                message = Text.translatable(activate
                        ? "message.noobvill_power.projector_enabled"
                        : "message.noobvill_power.projector_disabled");
            } else {
                return ActionResult.PASS;
            }

            if (state.get(ForceFieldProjectorBlock.ACTIVE)) {
                ForceFieldManager.deactivate((ServerWorld) world, pos);
            }
            world.setBlockState(pos, changed, 3);
            if (changed.get(ForceFieldProjectorBlock.ACTIVE)) {
                ForceFieldManager.activate((ServerWorld) world, pos);
            }
            player.sendMessage(message, true);
            return ActionResult.SUCCESS;
        });
    }

    private static BlockState adjustOffset(BlockState state,
            net.minecraft.state.property.IntProperty property, boolean reverse) {
        int current = state.get(property);
        int next = reverse ? Math.max(-2, current - 1) : Math.min(2, current + 1);
        return state.with(property, next);
    }

    private static void registerProtection() {
        AttackBlockCallback.EVENT.register((player, world, hand, pos, direction) ->
                world.getBlockState(pos).isOf(ModContent.FORCE_FIELD) ? ActionResult.FAIL : ActionResult.PASS);

        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) ->
                !state.isOf(ModContent.FORCE_FIELD));

        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (world instanceof ServerWorld serverWorld && state.isOf(ModContent.FORCE_FIELD_PROJECTOR)) {
                ForceFieldManager.deactivate(serverWorld, pos);
            }
        });

        UseItemCallback.EVENT.register((player, world, hand) -> {
            ItemStack stack = player.getStackInHand(hand);
            if (stack.isOf(Items.CHORUS_FRUIT) && world instanceof ServerWorld serverWorld
                    && ForceFieldManager.isNearActiveField(serverWorld, player.getEntityPos(), 4.0)) {
                player.sendMessage(Text.translatable("message.noobvill_power.teleport_blocked"), true);
                return ActionResult.FAIL;
            }
            return ActionResult.PASS;
        });
    }
}
