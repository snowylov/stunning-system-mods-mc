package com.noobvill.power;

import java.util.function.BiConsumer;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.explosion.Explosion;

/** An explosion-proof field segment. Only the force-field manager may remove it. */
public final class ForceFieldBlock extends Block {
    public ForceFieldBlock(Settings settings) {
        super(settings);
    }

    @Override
    protected void onExploded(BlockState state, ServerWorld world, BlockPos pos, Explosion explosion,
            BiConsumer<ItemStack, BlockPos> stackMerger) {
        // Deliberately immune to every ordinary explosion. EMPs call the manager directly.
    }
}
