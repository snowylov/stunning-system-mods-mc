package com.noobvill.power;

import java.util.Map;

import net.minecraft.item.equipment.ArmorMaterial;
import net.minecraft.item.equipment.EquipmentAsset;
import net.minecraft.item.equipment.EquipmentAssetKeys;
import net.minecraft.item.equipment.EquipmentType;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.sound.SoundEvents;

public final class ModArmorMaterials {
    public static final ArmorMaterial HAZMAT_MASK = create("hazmat_mask");
    public static final ArmorMaterial HAZMAT_SHIRT = create("hazmat_shirt");
    public static final ArmorMaterial HAZMAT_PANTS = create("hazmat_pants");
    public static final ArmorMaterial RUBBER_BOOTS = create("rubber_boots");

    private ModArmorMaterials() {
    }

    private static ArmorMaterial create(String name) {
        RegistryKey<EquipmentAsset> asset = RegistryKey.of(EquipmentAssetKeys.REGISTRY_KEY, NoobvillPower.id(name));
        Map<EquipmentType, Integer> defense = Map.of(
                EquipmentType.BOOTS, 1,
                EquipmentType.LEGGINGS, 2,
                EquipmentType.CHESTPLATE, 3,
                EquipmentType.HELMET, 1);
        return new ArmorMaterial(5, defense, 15, SoundEvents.ITEM_ARMOR_EQUIP_LEATHER,
                0.0F, 0.0F, ItemTags.REPAIRS_LEATHER_ARMOR, asset);
    }
}
