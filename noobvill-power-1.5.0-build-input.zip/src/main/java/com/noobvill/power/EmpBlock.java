package com.noobvill.power;

import java.util.function.BiConsumer;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;
import net.minecraft.world.block.WireOrientation;
import net.minecraft.world.explosion.Explosion;
import org.jetbrains.annotations.Nullable;

/** TNT-style pulse charge that temporarily breaches only force-field blocks. */
public final class EmpBlock extends Block {
    public static final BooleanProperty PRIMED = BooleanProperty.of("primed");
    private static final int FUSE_TICKS = 80;
    private static final int BREACH_RADIUS = 3;

    public EmpBlock(Settings settings) {
        super(settings);
        setDefaultState(getStateManager().getDefaultState().with(PRIMED, false));
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(PRIMED);
    }

    @Override
    protected void onBlockAdded(BlockState state, World world, BlockPos pos, BlockState oldState, boolean notify) {
        super.onBlockAdded(state, world, pos, oldState, notify);
        if (!world.isClient() && world.isReceivingRedstonePower(pos)) {
            prime((ServerWorld) world, pos, state);
        }
    }

    @Override
    protected void neighborUpdate(BlockState state, World world, BlockPos pos, Block sourceBlock,
            @Nullable WireOrientation wireOrientation, boolean notify) {
        super.neighborUpdate(state, world, pos, sourceBlock, wireOrientation, notify);
        if (!world.isClient() && !state.get(PRIMED) && world.isReceivingRedstonePower(pos)) {
            prime((ServerWorld) world, pos, state);
        }
    }

    @Override
    protected ActionResult onUseWithItem(ItemStack stack, BlockState state, World world, BlockPos pos,
            PlayerEntity player, Hand hand, BlockHitResult hit) {
        if (!stack.isOf(Items.FLINT_AND_STEEL) && !stack.isOf(Items.FIRE_CHARGE)) {
            return ActionResult.PASS;
        }
        if (state.get(PRIMED)) {
            return ActionResult.SUCCESS;
        }
        if (!world.isClient()) {
            if (stack.isOf(Items.FLINT_AND_STEEL)) {
                stack.damage(1, player);
            } else {
                stack.decrementUnlessCreative(1, player);
            }
            prime((ServerWorld) world, pos, state);
        }
        return ActionResult.SUCCESS;
    }

    @Override
    protected void scheduledTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
        if (state.get(PRIMED)) {
            detonate(world, pos, true);
        }
    }

    @Override
    protected void onExploded(BlockState state, ServerWorld world, BlockPos pos, Explosion explosion,
            BiConsumer<ItemStack, BlockPos> stackMerger) {
        detonate(world, pos, false);
    }

    private void prime(ServerWorld world, BlockPos pos, BlockState state) {
        if (state.get(PRIMED)) {
            return;
        }
        world.setBlockState(pos, state.with(PRIMED, true), Block.NOTIFY_ALL);
        world.scheduleBlockTick(pos, this, FUSE_TICKS);
        world.playSound(null, pos, SoundEvents.ENTITY_TNT_PRIMED, SoundCategory.BLOCKS, 1.0F, 1.0F);
    }

    private void detonate(ServerWorld world, BlockPos pos, boolean requirePlacedBlock) {
        if (requirePlacedBlock && !world.getBlockState(pos).isOf(this)) {
            return;
        }
        if (world.getBlockState(pos).isOf(this)) {
            world.removeBlock(pos, false);
        }
        ForceFieldManager.createEmpBreach(world, pos, BREACH_RADIUS);
        world.spawnParticles(ParticleTypes.EXPLOSION_EMITTER,
                pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
                1, 0.0, 0.0, 0.0, 0.0);
        world.playSound(null, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
                SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.BLOCKS, 4.0F, 1.0F);
    }
}
