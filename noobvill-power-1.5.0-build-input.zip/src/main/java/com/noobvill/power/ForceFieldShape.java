package com.noobvill.power;

import net.minecraft.util.StringIdentifiable;

public enum ForceFieldShape implements StringIdentifiable {
    CUBE("cube"),
    SPHERE("sphere"),
    CYLINDER("cylinder"),
    TUBE("tube");

    private final String id;

    ForceFieldShape(String id) {
        this.id = id;
    }

    @Override
    public String asString() {
        return id;
    }
}
