package com.noobvill.power;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import net.minecraft.block.BlockState;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public final class ForceFieldManager {
    private static final Map<ServerWorld, Set<BlockPos>> ACTIVE_PROJECTORS = new HashMap<>();
    private static final Map<ServerWorld, Map<BlockPos, Long>> EMP_BREACHES = new HashMap<>();
    private static final int HEART_RANGE = 3;
    private static final long EMP_BREACH_DURATION = 300L;

    private ForceFieldManager() {
    }

    public static void activate(ServerWorld world, BlockPos projectorPos) {
        ACTIVE_PROJECTORS.computeIfAbsent(world, ignored -> new HashSet<>()).add(projectorPos.toImmutable());
        rebuild(world, projectorPos);
    }

    public static void deactivate(ServerWorld world, BlockPos projectorPos) {
        Set<BlockPos> projectors = ACTIVE_PROJECTORS.get(world);
        if (projectors != null) {
            projectors.remove(projectorPos);
        }
        removeField(world, projectorPos, world.getBlockState(projectorPos));
    }

    public static void tick(ServerWorld world) {
        Set<BlockPos> projectors = ACTIVE_PROJECTORS.computeIfAbsent(world, ignored -> new HashSet<>());
        Map<BlockPos, Long> breaches = EMP_BREACHES.computeIfAbsent(world, ignored -> new HashMap<>());
        boolean breachExpired = breaches.entrySet().removeIf(entry -> entry.getValue() <= world.getTime());

        // Re-discovers saved active projectors near players after a world restart.
        if (world.getTime() % 100L == 0L) {
            world.getPlayers().forEach(player -> {
                BlockPos origin = player.getBlockPos();
                for (BlockPos pos : BlockPos.iterate(origin.add(-12, -12, -12), origin.add(12, 12, 12))) {
                    BlockState state = world.getBlockState(pos);
                    if (state.isOf(ModContent.FORCE_FIELD_PROJECTOR)
                            && state.get(ForceFieldProjectorBlock.ACTIVE)) {
                        projectors.add(pos.toImmutable());
                    }
                }
            });
        }

        Iterator<BlockPos> iterator = projectors.iterator();
        List<BlockPos> rebuild = new ArrayList<>();
        while (iterator.hasNext()) {
            BlockPos pos = iterator.next();
            BlockState state = world.getBlockState(pos);
            if (!state.isOf(ModContent.FORCE_FIELD_PROJECTOR)
                    || !state.get(ForceFieldProjectorBlock.ACTIVE)) {
                removeField(world, pos, state);
                iterator.remove();
                continue;
            }
            if (!hasHeart(world, pos)) {
                removeField(world, pos, state);
                world.setBlockState(pos, state.with(ForceFieldProjectorBlock.ACTIVE, false), 3);
                iterator.remove();
                continue;
            }
            if (world.getTime() % 40L == 0L) {
                rebuild.add(pos);
            }
        }
        if (breachExpired) {
            rebuild.addAll(projectors);
        }
        rebuild.forEach(pos -> rebuild(world, pos));
    }

    public static void createEmpBreach(ServerWorld world, BlockPos origin, int radius) {
        createEmpBreach(world, origin, radius, EMP_BREACH_DURATION);
    }

    public static void createEmpBreach(ServerWorld world, BlockPos origin, int radius, long durationTicks) {
        if (radius < 0) {
            throw new IllegalArgumentException("EMP breach radius cannot be negative");
        }
        if (durationTicks <= 0L) {
            throw new IllegalArgumentException("EMP breach duration must be positive");
        }

        long restoreAt = world.getTime() + durationTicks;
        Map<BlockPos, Long> breaches = EMP_BREACHES.computeIfAbsent(world, ignored -> new HashMap<>());
        int radiusSquared = radius * radius;
        for (BlockPos candidate : BlockPos.iterate(origin.add(-radius, -radius, -radius),
                origin.add(radius, radius, radius))) {
            int deltaX = candidate.getX() - origin.getX();
            int deltaY = candidate.getY() - origin.getY();
            int deltaZ = candidate.getZ() - origin.getZ();
            if (deltaX * deltaX + deltaY * deltaY + deltaZ * deltaZ <= radiusSquared
                    && world.getBlockState(candidate).isOf(ModContent.FORCE_FIELD)) {
                BlockPos breachedPos = candidate.toImmutable();
                world.removeBlock(breachedPos, false);
                breaches.put(breachedPos, restoreAt);
            }
        }
    }

    public static boolean hasHeart(ServerWorld world, BlockPos projectorPos) {
        for (BlockPos pos : BlockPos.iterate(projectorPos.add(-HEART_RANGE, -HEART_RANGE, -HEART_RANGE),
                projectorPos.add(HEART_RANGE, HEART_RANGE, HEART_RANGE))) {
            if (world.getBlockState(pos).isOf(ModContent.REDSTONE_HEART)) {
                return true;
            }
        }
        return false;
    }

    public static boolean isNearActiveField(ServerWorld world, Vec3d point, double margin) {
        Set<BlockPos> projectors = ACTIVE_PROJECTORS.get(world);
        if (projectors == null) {
            return false;
        }
        for (BlockPos pos : projectors) {
            BlockState state = world.getBlockState(pos);
            if (!state.isOf(ModContent.FORCE_FIELD_PROJECTOR)) {
                continue;
            }
            BlockPos center = center(pos, state);
            int radius = state.get(ForceFieldProjectorBlock.RADIUS);
            if (point.squaredDistanceTo(Vec3d.ofCenter(center)) <= (radius + margin) * (radius + margin)) {
                return true;
            }
        }
        return false;
    }

    public static boolean blocksTeleport(ServerWorld world, Vec3d from, Vec3d to) {
        Set<BlockPos> projectors = ACTIVE_PROJECTORS.get(world);
        if (projectors == null) {
            return false;
        }
        for (BlockPos pos : projectors) {
            BlockState state = world.getBlockState(pos);
            if (!state.isOf(ModContent.FORCE_FIELD_PROJECTOR)
                    || !state.get(ForceFieldProjectorBlock.ACTIVE)) {
                continue;
            }
            BlockPos center = center(pos, state);
            int radius = state.get(ForceFieldProjectorBlock.RADIUS);
            ForceFieldShape shape = state.get(ForceFieldProjectorBlock.SHAPE);
            if (isInside(shape, from, center, radius) != isInside(shape, to, center, radius)) {
                return true;
            }
        }
        return false;
    }

    public static void rebuild(ServerWorld world, BlockPos projectorPos) {
        BlockState state = world.getBlockState(projectorPos);
        if (!state.isOf(ModContent.FORCE_FIELD_PROJECTOR)
                || !state.get(ForceFieldProjectorBlock.ACTIVE)
                || !hasHeart(world, projectorPos)) {
            return;
        }

        BlockPos center = center(projectorPos, state);
        int radius = state.get(ForceFieldProjectorBlock.RADIUS);
        ForceFieldShape shape = state.get(ForceFieldProjectorBlock.SHAPE);
        for (int x = -radius; x <= radius; x++) {
            for (int y = -radius; y <= radius; y++) {
                for (int z = -radius; z <= radius; z++) {
                    if (!isShell(shape, x, y, z, radius)) {
                        continue;
                    }
                    BlockPos target = center.add(x, y, z);
                    if (world.getBlockState(target).isAir() && !isEmpBreached(world, target)) {
                        world.setBlockState(target, ModContent.FORCE_FIELD.getDefaultState(), 2);
                    }
                }
            }
        }
    }

    private static boolean isEmpBreached(ServerWorld world, BlockPos pos) {
        Map<BlockPos, Long> breaches = EMP_BREACHES.get(world);
        return breaches != null && breaches.getOrDefault(pos, 0L) > world.getTime();
    }

    private static void removeField(ServerWorld world, BlockPos projectorPos, BlockState state) {
        int radius = state.contains(ForceFieldProjectorBlock.RADIUS)
                ? state.get(ForceFieldProjectorBlock.RADIUS) : 8;
        BlockPos center = state.isOf(ModContent.FORCE_FIELD_PROJECTOR) ? center(projectorPos, state) : projectorPos;
        int cleanupRadius = Math.max(8, radius + 2);
        for (BlockPos target : BlockPos.iterate(center.add(-cleanupRadius, -cleanupRadius, -cleanupRadius),
                center.add(cleanupRadius, cleanupRadius, cleanupRadius))) {
            if (world.getBlockState(target).isOf(ModContent.FORCE_FIELD)) {
                world.removeBlock(target, false);
            }
        }
    }

    private static BlockPos center(BlockPos projectorPos, BlockState state) {
        return projectorPos.add(
                state.get(ForceFieldProjectorBlock.OFFSET_X),
                state.get(ForceFieldProjectorBlock.OFFSET_Y),
                state.get(ForceFieldProjectorBlock.OFFSET_Z));
    }

    private static boolean isShell(ForceFieldShape shape, int x, int y, int z, int radius) {
        int edge = Math.max(Math.max(Math.abs(x), Math.abs(y)), Math.abs(z));
        double radial = Math.sqrt(x * x + z * z);
        double distance = Math.sqrt(x * x + y * y + z * z);
        return switch (shape) {
            case CUBE -> edge == radius;
            case SPHERE -> distance >= radius - 0.75 && distance <= radius + 0.35;
            case CYLINDER -> Math.abs(y) == radius || radial >= radius - 0.75 && radial <= radius + 0.35;
            case TUBE -> radial >= radius - 0.75 && radial <= radius + 0.35;
        };
    }

    private static boolean isInside(ForceFieldShape shape, Vec3d point, BlockPos center, int radius) {
        double x = point.x - (center.getX() + 0.5);
        double y = point.y - (center.getY() + 0.5);
        double z = point.z - (center.getZ() + 0.5);
        double radial = Math.sqrt(x * x + z * z);
        return switch (shape) {
            case CUBE -> Math.max(Math.max(Math.abs(x), Math.abs(y)), Math.abs(z)) < radius;
            case SPHERE -> Math.sqrt(x * x + y * y + z * z) < radius;
            case CYLINDER -> radial < radius && Math.abs(y) < radius;
            case TUBE -> false; // A tube intentionally has open ends and does not enclose a volume.
        };
    }
}
