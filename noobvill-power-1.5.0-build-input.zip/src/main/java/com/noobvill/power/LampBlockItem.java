package com.noobvill.power;

import java.util.function.Consumer;

import net.minecraft.block.Block;
import net.minecraft.component.type.TooltipDisplayComponent;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/** Block item with the in-game instructions requested for every powered lamp. */
public final class LampBlockItem extends BlockItem {
    private final String effectTooltipKey;

    public LampBlockItem(Block block, Item.Settings settings, String effectTooltipKey) {
        super(block, settings);
        this.effectTooltipKey = effectTooltipKey;
    }

    @Override
    @SuppressWarnings("deprecation")
    public void appendTooltip(ItemStack stack, Item.TooltipContext context,
            TooltipDisplayComponent displayComponent, Consumer<Text> textConsumer, TooltipType type) {
        textConsumer.accept(Text.translatable("tooltip.noobvill_power.lamp_mode").formatted(Formatting.GRAY));
        textConsumer.accept(Text.translatable(effectTooltipKey).formatted(Formatting.AQUA));
    }
}
