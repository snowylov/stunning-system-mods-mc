package com.noobvill.power;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.state.property.IntProperty;

public final class ForceFieldProjectorBlock extends Block {
    public static final BooleanProperty ACTIVE = BooleanProperty.of("active");
    public static final EnumProperty<ForceFieldShape> SHAPE =
            EnumProperty.of("shape", ForceFieldShape.class);
    public static final IntProperty RADIUS = IntProperty.of("radius", 2, 8);
    public static final IntProperty OFFSET_X = IntProperty.of("offset_x", -2, 2);
    public static final IntProperty OFFSET_Y = IntProperty.of("offset_y", -2, 2);
    public static final IntProperty OFFSET_Z = IntProperty.of("offset_z", -2, 2);

    public ForceFieldProjectorBlock(Settings settings) {
        super(settings);
        setDefaultState(getStateManager().getDefaultState()
                .with(ACTIVE, false)
                .with(SHAPE, ForceFieldShape.CUBE)
                .with(RADIUS, 4)
                .with(OFFSET_X, 0)
                .with(OFFSET_Y, 0)
                .with(OFFSET_Z, 0));
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(ACTIVE, SHAPE, RADIUS, OFFSET_X, OFFSET_Y, OFFSET_Z);
    }
}
