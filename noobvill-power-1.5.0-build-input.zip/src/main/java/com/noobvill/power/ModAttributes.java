package com.noobvill.power;

import net.minecraft.entity.attribute.ClampedEntityAttribute;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.entry.RegistryEntry;

public final class ModAttributes {
    public static final RegistryEntry<EntityAttribute> FALL_DAMAGE_REDUCTION = register(
            "fall_damage_reduction", 0.0, 0.0, 1.0);
    public static final RegistryEntry<EntityAttribute> UNDERWATER_BREATHING = register(
            "underwater_breathing", 0.0, 0.0, 1.0);
    public static final RegistryEntry<EntityAttribute> DARK_VISION = register(
            "dark_vision", 0.0, 0.0, 1.0);
    public static final RegistryEntry<EntityAttribute> HAZARD_IMMUNITY = register(
            "hazard_immunity", 0.0, 0.0, 1.0);

    private ModAttributes() {
    }

    public static void initialize() {
        // Loading this class registers the attributes.
    }

    private static RegistryEntry<EntityAttribute> register(String name, double fallback, double min, double max) {
        EntityAttribute attribute = new ClampedEntityAttribute(
                "attribute.name.noobvill_power." + name, fallback, min, max).setTracked(true);
        return Registry.registerReference(Registries.ATTRIBUTE, NoobvillPower.id(name), attribute);
    }
}
