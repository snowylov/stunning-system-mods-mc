package com.noobvill.power.mixin;

import com.noobvill.power.ModAttributes;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GameRenderer.class)
public abstract class GameRendererHazmatMixin {
    @Inject(method = "getNightVisionStrength", at = @At("RETURN"), cancellable = true)
    private static void noobvillPower$applyDarkVision(LivingEntity entity, float tickProgress,
            CallbackInfoReturnable<Float> cir) {
        float darkVision = (float) entity.getAttributeValue(ModAttributes.DARK_VISION);
        if (darkVision > cir.getReturnValue()) {
            cir.setReturnValue(darkVision);
        }
    }
}
