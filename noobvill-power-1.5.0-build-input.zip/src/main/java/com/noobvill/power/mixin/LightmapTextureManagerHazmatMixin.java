package com.noobvill.power.mixin;

import com.noobvill.power.ModAttributes;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.LightmapTextureManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LightmapTextureManager.class)
public abstract class LightmapTextureManagerHazmatMixin {
    @Inject(method = "getBrightness(FI)F", at = @At("RETURN"), cancellable = true)
    private static void noobvillPower$applyDarkVision(float ambientLight, int lightLevel,
            CallbackInfoReturnable<Float> cir) {
        ClientPlayerEntity player = MinecraftClient.getInstance().player;
        if (player == null) {
            return;
        }
        float darkVision = (float) player.getAttributeValue(ModAttributes.DARK_VISION);
        float brightness = cir.getReturnValue();
        cir.setReturnValue(brightness + (1.0F - brightness) * darkVision);
    }
}
