package com.noobvill.power.mixin;

import com.noobvill.power.ForceFieldManager;
import net.minecraft.entity.LivingEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
abstract class LivingEntityTeleportMixin {
    @Inject(method = "teleport(DDDZ)Z", at = @At("HEAD"), cancellable = true)
    private void noobvillPower$blockForceFieldTeleport(double x, double y, double z,
            boolean particleEffects, CallbackInfoReturnable<Boolean> callback) {
        LivingEntity entity = (LivingEntity) (Object) this;
        if (entity.getEntityWorld() instanceof ServerWorld world
                && ForceFieldManager.blocksTeleport(world, entity.getEntityPos(), new Vec3d(x, y, z))) {
            callback.setReturnValue(false);
        }
    }
}
