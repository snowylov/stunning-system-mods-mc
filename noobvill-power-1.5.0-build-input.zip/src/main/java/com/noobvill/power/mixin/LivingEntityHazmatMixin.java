package com.noobvill.power.mixin;

import com.noobvill.power.ModAttributes;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public abstract class LivingEntityHazmatMixin {
    @Inject(method = "createLivingAttributes", at = @At("RETURN"))
    private static void noobvillPower$addHazmatAttributes(
            CallbackInfoReturnable<DefaultAttributeContainer.Builder> cir) {
        cir.getReturnValue()
                .add(ModAttributes.FALL_DAMAGE_REDUCTION)
                .add(ModAttributes.UNDERWATER_BREATHING)
                .add(ModAttributes.DARK_VISION)
                .add(ModAttributes.HAZARD_IMMUNITY);
    }

    @Inject(method = "computeFallDamage", at = @At("RETURN"), cancellable = true)
    private void noobvillPower$reduceFallDamage(double fallDistance, float damageMultiplier,
            CallbackInfoReturnable<Integer> cir) {
        LivingEntity self = (LivingEntity) (Object) this;
        double reduction = self.getAttributeValue(ModAttributes.FALL_DAMAGE_REDUCTION);
        cir.setReturnValue((int) Math.ceil(cir.getReturnValue() * (1.0 - reduction)));
    }

    @Inject(method = "getNextAirUnderwater", at = @At("RETURN"), cancellable = true)
    private void noobvillPower$extendUnderwaterBreathing(int air,
            CallbackInfoReturnable<Integer> cir) {
        if (cir.getReturnValue() >= air) {
            return;
        }
        LivingEntity self = (LivingEntity) (Object) this;
        double bonus = self.getAttributeValue(ModAttributes.UNDERWATER_BREATHING);
        double preserveChance = bonus / (1.0 + bonus);
        if (self.getRandom().nextDouble() < preserveChance) {
            cir.setReturnValue(air);
        }
    }

    @Inject(method = "modifyAppliedDamage", at = @At("RETURN"), cancellable = true)
    private void noobvillPower$reduceHazardDamage(DamageSource source, float amount,
            CallbackInfoReturnable<Float> cir) {
        if (!source.isOf(DamageTypes.MAGIC)
                && !source.isOf(DamageTypes.INDIRECT_MAGIC)
                && !source.isOf(DamageTypes.WITHER)) {
            return;
        }
        LivingEntity self = (LivingEntity) (Object) this;
        double immunity = self.getAttributeValue(ModAttributes.HAZARD_IMMUNITY);
        cir.setReturnValue((float) (cir.getReturnValue() * (1.0 - immunity)));
    }
}
